/*

	CONTENTS ----------

	1.LIFEWAY FUNCTIONS & PLUGINS
		1.1 ADVANCED CSS
		1.2 NAVIGATION
			1.2.1 MENU DISPLAY
			1.2.2 MENU TOGGLE
			1.2.3 LIST TOGGLE
		1.3 TYPE AHEAD
		1.4 PRODUCT LIST
		1.5 WIDGETS
			1.5.1 ROTATOR
			1.5.2 SLIDER
			1.5.3 SLIDESHOW
			1.5.4 MEDIA
			1.5.5 MODAL
			1.5.6 PLUCK STARS FIX
		1.6 ENDECA PREVIEW
		1.7 FORMS
			1.7.1 PLACEHOLDER
			1.7.2 URL SELECTOR
		1.8 INTERNATIONAL ADDRESS VALIDATION ON EDIT PAYMENT PAGE
	2.3RD-PARTY PLUGINS
		2.1 HOVERINTENT
		2.2 BGIFRAME
		2.3 JPLAYER
		2.4 BOOTSTRAP TOOLTIPS

	-------------------

*/

/* 1.LIFEWAY FUNCTIONS & PLUGINS
---------------------------------------------------------------------- */

	/* 1.1 ADVANCED CSS ---------------------------------------------------------------------- */
	/* advanced_css.js */

	// Additional CSS hooks for older browsers without comprehensive selector support
	jQuery('tr:odd, ul.specifications li:even').addClass('odd');  // drop when ie8 is dropped
	jQuery('ul#address_book li:nth-child(3n+4), .org_address div.account div.form_input:nth-child(3n+2), .personal_address div.form_input:nth-child(3n+2)').addClass('first');  // drop when ie8 is dropped
	jQuery('div.secondary a:last-child, li:last-child, th:last-child, .col_double .tiled a:nth-child(5n+6), .col_full .tiled a:nth-child(6n+7)').addClass('last'); // drop when ie8 is dropped
	jQuery('ul#address_book li:nth-child(3n+2)').addClass('middle'); // drop when ie8 is dropped
	jQuery('.col_narrow .order_total p.total, .col_narrow .order_total p.pre-total').last().addClass('total'); // evaluate when ie8 is dropped

	// Special stuff only for IE7 - relies on modernizr - drop when ie7 is dropped
	if (jQuery('.no-generatedcontent').length) {
		jQuery('.no-generatedcontent ul.breadcrumbs li:not(:first-child)').before('<span style="padding:0 6px;">&#62;</span>');
		jQuery('.no-generatedcontent div.additional_info ul li:not(:first-child)').before('<span style="padding:0 6px;">|</span>')
	}



	/* 1.2 NAVIGATION ---------------------------------------------------------------------- */
	/* navigation.js */

	function showLWNavigation(navigation, index){
		if (typeof navigation != 'undefined') {
			var buf = "";
			var subheadingsArrayLength = navigation.subheadings.length;
			for(var i=0; i<subheadingsArrayLength; i++) {
				var children = navigation.subheadings[i].children;
				var childrenArrayLength = children.length;
				var child = "";
				var childClass= "";
				if(childrenArrayLength === 0){
					childClass = " class='no-child'";
				}
				buf += "<li" + childClass + "><a href=\"" + navigationUrl + navigation.subheadings[i].qry + "\">"
					+ navigation.subheadings[i].name + "</a>\n";
				if(childrenArrayLength > 0){
					child += "<ul class='nav-level-three'>";
				}
				for(var j=0; j<childrenArrayLength; j++) {
					child += "<li><a href=\"" + navigationUrl + children[j].qry + "\">"
						 + children[j].name + "</a></li>";
				}
				if(childrenArrayLength > 0){
					child += "</ul>";
				}
				buf += child + "</li>";
			}
			jQuery('#nav_'+index).html(buf);
		}
	}



		/* 1.2.1 MENU DISPLAY ---------------------------------------------------------------------- */
		// plugin lwMenu()
		// hoverIntent must be present before this plugin is called

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold standard hoverIntent settings
					// and a couple of other things
					var settings = {
						'topLevel'		: 'h4 a',
						'sensitivity'	: 3,
						'interval'		: 50,
						'timeout'		: 250
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);

						function showMenu() {
							// the hover class is the hook used in the CSS for all show/hide functionality
							$(this).addClass("hover");
							if ($(this).has('ul').length !== 0 && $(this).parents('li').length !== 0) {
								// variables and measurements
								var $currentMenu = $(this).parent('ul');
								var $newMenu = $(this).children('ul');
								var position = $(this).position();
								var currentHeight = $(this).outerHeight();
								var currentMenuHeight = $currentMenu.innerHeight();
								var newMenuHeight = $newMenu.innerHeight();
								var newMenuBorderOffset = ($newMenu.outerHeight() - $newMenu.height()) / 2;
								// let's see if the menu extends past the bottom of the parent menu
								if (currentMenuHeight - position.top - newMenuHeight < 0) {
									// if there is enought room, let's pin the flyout to the bottom
									if (currentMenuHeight >= newMenuHeight) {
										var newBottom = position.top + currentHeight - currentMenuHeight - newMenuBorderOffset;
										$newMenu.css({
											"top" : "auto",
											"bottom" : newBottom+"px"
										});
									// if there isn't enought room, let's pin the flyout to the top
									} else {
										var newTop = - position.top - newMenuBorderOffset;
										$newMenu.css({
											"top" : newTop+"px",
											"bottom" : "auto"
										});
									}
								}
							}
						}

						function hideMenu() {
							// the hover class is the hook used in the CSS for all show/hide functionality
							$(this).removeClass("hover");
						}

						// menu interaction
						$this
						// add the ready class to the menu - we'll use this to override some CSS styles when the menu initiates
						.addClass('ready')
						// use delegate to bind hoverIntent functionality to any li that is added to the menu
						// first, we call mouseover with the delegate method
						.delegate('li', "mouseover", function() {
							// check to see it hoveIntent has been initiated
							if (!$(this).data('init')) {
								// save the initiation information with the element
								$(this).data('init', true);
								// attach the hoverIntent functionality
								$(this).hoverIntent({
									sensitivity: settings.sensitivity,
									interval: settings.interval,
									over: showMenu,
									timeout: settings.timeout,
									out: hideMenu
								});
								// now that hoverIntent has been attached, fire the mouseover event again so the menu actually flys-out
								$(this).trigger('mouseover');
							}
						})
						// prevent click functionality on top level menu tabs
						// (to prevent user confusion when attempting to make the menu appear)
						.delegate(settings.topLevel, "click", function(e) {
							e.preventDefault();
						})
						// fire bgiframe for all lists to prevent form peek through problems in IE
						.find('ul').bgiframe();
				    });
				}
			};

			$.fn.lwMenu = function(method) {
				// Method calling logic
			    if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
			    } else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
			    } else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwMenu');
			    }
			};
		})(jQuery);



		/* 1.2.2 MENU TOGGLE ---------------------------------------------------------------------- */
		// plugin lwMenuToggle()
		// used for the refinement menu on the list pages

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the menu elements
					var settings = {
						'hideTrigger'	: 'collapse'
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);

						// go ahead and hide the next element if the hideTrigger class is present
						if ($this.hasClass(settings.hideTrigger)) {
							$this.next().hide();
						}

						// add a link for hover effect in all browsers
						$this.wrapInner('<a href="#"></a>');

						// set the click functionality
						$this.click(function(e) {
							e.preventDefault();
							// swap out the classes, and slide the next element
						    jQuery(this).toggleClass("collapse").toggleClass("expand").next().slideToggle('slow');
						});
					});
				}
			};

			$.fn.lwMenuToggle = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwMenuToggle');
				}
			};
		})(jQuery);



		/* 1.2.3 LIST TOGGLE ---------------------------------------------------------------------- */
		// plugin lwListToggle()
		// used for the matching categories on search results page

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the menu elements
					var settings = {
						'itemThreshold'	: 7,
						'itemsShown'	: 3
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);
						var listItems = $this.find('li').length;

						if (listItems > settings.itemThreshold) {
							settings.itemsShown = settings.itemsShown - 1;
							$this.find('li:gt('+settings.itemsShown+')').wrapAll('<div class="extra"></div>').parent().after('<a href="#" class="extra">view more</a>');
							$this.find('a.extra').click(function(e) {
								e.preventDefault();
								$(this).prev().slideToggle('slow', function() {
									if ($(this).next().text() === "view more") {
										$(this).next().text("view less");
									} else {
										$(this).next().text("view more");
									}
								});
							});
						}
					});
				}
			};

			$.fn.lwListToggle = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwListToggle');
				}
			};
		})(jQuery);



	/* 1.3 TYPE AHEAD ---------------------------------------------------------------------- */
	/* navigation.js */

	// Type Ahead
	var HIGHLIGHT_CLASS = "highlight";

	(function(jQuery) {
		jQuery.fn.extend( {
			typeahead : function(options) {
				return this.each(function() {
					new jQuery.typeaheadz(this, options);
				});
			},
			typeahead_configure : function(options) {
				return this.trigger("typeahead_configure", [ options ]);
			},
			typeahead_load : function() {
				return this.trigger("typeahead_load");
			},
			typeahead_clear : function() {
				return this.trigger("typeahead_clear");
			}
		});
		jQuery.typeaheadz = function(input, options) {
			var inputbox = input;
			var typeAheadContainer = jQuery('#header');
			var defaults = {
				field : 'tags' // id of input control (textbox or text area)
				,url : 'jsontags.php' // the remote url to get the suggestion list from
				,tagsep : '' // multi-value delimiter of field
				,enclose : '' // character to enclose multi-word filters
				,max : 12 // maximum number of results to show in the suggestion list - keep equal to LWNavigationHelper.DEFAULT_NUMBER_OF_RECORDS
				,cache : true // cache results from suggestion list or not
				,delay : 500 // pause after which the suggestion list is loaded
				,charMin : 1 // minimum number of chars for filter before a lookup is done
				,dblClick : true // activate suggestion list on double click?
				,postData : null // extra post data specified in object notation
				,visible : true // indicates whether the lookup list will be shown when there are suggestions
				,dataType : 'jsonp' // datatype of return results
				,jsonp : 'jsonp_callback'
				,method : 'GET'
				,onRenderItem : function(row) {
					return decodeURIComponent(row);
				}
				,onSelectItem : function(val) {
					return true;
				}
				,onSelectedItem : function(index, char_count, chars_typed, val, e) {
					return true;
				}
				,onDefaultEnter : function(e){
					return true;
				}
				,onLoadList : function(filter) {
					return true;
				}
				,onLoadedList : function(results) {
					return true;
				}
			};
			var options = jQuery.extend(defaults, options);
			var input = jQuery('#' + options.field);
			var char_count = 0;
			jQuery(input).attr("autocomplete", "off");

			var lkup = jQuery('<div />');
			lkup.attr( {'id' : 'search_ahead'});

			jQuery(lkup, typeAheadContainer).hide();
			jQuery('#SearchForm').after(lkup);

			var lkupHeader = jQuery('<h3 />');
			lkupHeader.text("Recommended Searches");
			jQuery(lkup, typeAheadContainer).append(lkupHeader);

			var lkuplst = jQuery('<ol />');
			jQuery(lkup, typeAheadContainer).append(lkuplst);

			var cursor = -1; // keyboard arrow cursor in suggestion list (0=first position, -1 = no position)
			var length = 0; // length of last suggestion list
			var loading = false; // loading indicator of suggestion list
			var loaded = false; // loaded indicator of suggestion list
			var cacheLst = null; // in-memory suggestion list, used for containing the rich objects inside
			var inserted = false; // state variable to prevent double suggestion list after inserting a value

			var preg_escape = function(str) {
				return (str + '').replace(/([\\\.\+\*\?\[\^\]\$\(\)\{\}\=\!<>\|\:])/g, "\\$1");
			};

			var hideLkup = function() {
				jQuery(lkuplst, typeAheadContainer).empty();
				jQuery(lkup, typeAheadContainer).hide();
				loaded = false;
				cacheLst = null;
				inserted = false;
			};

			var updateStatistics = function(term_clicked) {
				var term_location = 0;
				var num_keystrokes = jQuery('#Keyword').val().length;
				if (cacheLst !== null){
					var numberOfItems = cacheLst.length;
					var i;
					for (i = 0; i < numberOfItems; i++) {
						if (cacheLst[i] == term_clicked) {
							term_location = i+1;
							break;
						}
					}
				}
				objOmni.lw2TypeaheadClick(term_clicked, term_location, num_keystrokes);
			};

			var insertTag = function(filter, tag) {
				var cur = input.val();
				var words = tag.split(' ').length;
				var enclose = (words > 1) ? options.enclose.length > 0 ? options.enclose: '': '';
				cur = cur.replace(eval('/' + preg_escape(filter) + '$/i'), enclose + tag + enclose);
				input.val(cur);
			};

			var addItem = function(val, filter, index) {
				if (!options.visible) return;

				var row = val;
				var val = options.onRenderItem(val, index, length, filter);

				var li = jQuery('<li/>');
				li.bind('mouseover', function(e){
					var e = e || window.event;
					if (cursor > -1)
						jQuery('li:eq(' + cursor + ')', typeAheadContainer).removeClass(HIGHLIGHT_CLASS);
					cursor = index;
					jQuery('li:eq(' + cursor + ')', typeAheadContainer).addClass(HIGHLIGHT_CLASS);
				});
				lkuplst.append(li);

				var aLink = jQuery('<a/>');
				aLink.attr( {'href' : '#'});
				jQuery(aLink, typeAheadContainer).text(val);
				jQuery(aLink, typeAheadContainer).html(jQuery(aLink, typeAheadContainer).text().replace(eval('/(' + preg_escape(filter) + ')/gi'),"<em>$1</em>"));
				li.append(aLink);

				aLink.click(function(e) {
					updateStatistics(aLink.text());
					inserted = true;
					var cur = input.val();
					options.onSelectItem(row);
					insertTag(filter, val);
					options.onSelectedItem(index, cur.length, cur, row, e);
					e.preventDefault();
					hideLkup();
					inserted = true;
				});
			};

			var loadList = function() {
				inserted = false;

				var filter = parseFilter(input.val());
				if (options.onLoadList(filter)){
					jQuery(lkuplst, typeAheadContainer).empty();
					jQuery.ajax( {
						type		: options.method
						,url		: options.url
						,data		: jQuery.extend({
											ahead : encodeURIComponent(filter.replace(/\s+$/g, '')) + "*",
											total : options.max
										}, options.postData)
						,dataType	: options.dataType
						,jsonp		: options.jsonp
						,cache		: options.cache
						,success	: function(json) {
											if (filter != parseFilter(input.val())) {
												loadList();
											} else {
												jQuery(lkuplst, typeAheadContainer).empty();
												length = json.length;
												cacheLst = json;
												cursor = -1;
												for (i = 0; i < json.length && i < options.max; i++) {
													addItem(json[i], filter, i);
												}
												if (options.visible && json.length > 0) {
													jQuery(lkup, typeAheadContainer).show();
												} else {
													jQuery(lkup, typeAheadContainer).hide();
												}
												loading = false;
												loaded = true;
												options.onLoadedList(json);
											}
										}
						,error		: function(XMLHttpRequest, textStatus, errorThrown) {
											length = 0;
											cacheLst = null;
											loading = false;
											loaded = false;
											options.onLoadedList(false);
										}
					});
				};
			};

			var parseFilter = function(val) {
				if (options.tagsep.length == 0)
					return val;

				if (val.indexOf(options.tagsep) > -1) {
					if (options.tagsep == ' ')
						val = val.substring(val.lastIndexOf(options.tagsep) + 1,val.length);
					else
						val = jQuery.trim(val.substring(val.lastIndexOf(options.tagsep) + 1, val.length));
				}
				return val;
			};

			var triggerLoad = function() {
				if (inserted) return false;
				else {
					var filter = parseFilter(input.val());

					if (filter.length >= options.charMin) {
						loading = true;
						setTimeout(function() {loadList()},options.delay);
					} else { hideLkup(); }
				}
			}

			input.dblclick(function(e){
				if (options.dblClick && !loading) triggerLoad();
			});

			jQuery(lkuplst, typeAheadContainer).blur(function(e) {
				hideLkup();
			});

			var handleSpecials = function(e) {
				var e = e || window.event;
				var key = e.charCode || e.keyCode;
				var cur = input.val();

				if (!loaded){
					switch (key) {
						case 40: { //Down key pressed
								triggerLoad();
							}
							break;
					}
					return true;
				}

				switch (key) {
					case 9: {// TAB key pressed
							cursor = ((cursor + 1) < length) ? cursor++ : cursor;
							if (cursor < length) {
								jQuery('li:eq(' + cursor + ')', typeAheadContainer).addClass(HIGHLIGHT_CLASS);
								if ((cursor - 1) > -1)
									jQuery('li:eq(' + (cursor - 1) + ')', typeAheadContainer).removeClass(HIGHLIGHT_CLASS);
									e.preventDefault();
							}
						}
						break;
					case 40: {// DOWN key pressed
							if ((cursor+1) < length) {
								cursor++;
								jQuery('li:eq(' + cursor + ')', typeAheadContainer).addClass(HIGHLIGHT_CLASS);
								if ((cursor - 1) > -1)
									jQuery('li:eq(' + (cursor - 1) + ')', typeAheadContainer).removeClass(HIGHLIGHT_CLASS);
								e.preventDefault();
							}else if((cursor+1) == length){
								jQuery('li:eq(' + cursor + ')', typeAheadContainer).removeClass(HIGHLIGHT_CLASS);
								cursor = 0;
								jQuery('li:eq(' + cursor + ')', typeAheadContainer).addClass(HIGHLIGHT_CLASS);
								e.preventDefault();
							}
						}
						break;
					case 38: {// UP key pressed
							if ((cursor - 1) >= 0) {
								cursor--;
								jQuery('li:eq(' + cursor + ')', typeAheadContainer).addClass(HIGHLIGHT_CLASS);
								jQuery('li:eq(' + (cursor + 1) + ')', typeAheadContainer).removeClass(HIGHLIGHT_CLASS);
								e.preventDefault();
							}else if (cursor == 0){
								hideLkup();
							}
						}
						break;
					case 13: {// ENTER key pressed
							if (cursor >= 0 && cursor < length) {
								var row = cacheLst[cursor];
								updateStatistics(row);
								options.onSelectItem(row);
								insertTag(parseFilter(input.val()), jQuery('li:eq(' + (cursor) + ')', typeAheadContainer).text());
								options.onSelectedItem(cursor, cur.length, cur, row, e);
								e.preventDefault();
								hideLkup();
							}else{
								options.onDefaultEnter(e);
								e.preventDefault();
							}
						}
						break;
					case 27: {// ESC key pressed
							hideLkup();
							e.preventDefault();
						}
						break;
					case 39: {// Right arrow
							if (typeof(input[0].selectionEnd) != "undefined"){
								if (input[0].selectionEnd == input[0].selectionStart && input[0].selectionEnd == input[0].textLength){
									if (input[0].type != "textarea")
										e.preventDefault();
									if (cursor >= 0 && cursor < length) {
										var row = cacheLst[cursor];
										options.onSelectItem(row);
										insertTag(parseFilter(input.val()), jQuery('li:eq(' + (cursor) + ')', typeAheadContainer).text());
										options.onSelectedItem(cursor, cur.length, cur, row, e);
										e.preventDefault();
										hideLkup();
									}
								}
							}else{
								var end = caretEnd();
								var start = caretStart();
								if (start == end && end == input.val().length){
									if (input[0].type != "textarea")
										e.preventDefault();
									if (cursor >= 0 && cursor < length) {
										var row = cacheLst[cursor];
										options.onSelectItem(row);
										insertTag(parseFilter(input.val()), jQuery('li:eq(' + (cursor) + ')', typeAheadContainer).text());
										options.onSelectedItem(cursor, cur.length, cur, row, e);
										e.preventDefault();
										hideLkup();
									}
								}
							}
						}
						break;
				}
			};

			var caretStart = function () {
				var bookmark = document.selection.createRange().getBookmark();
				input[0].selection = input[0].createTextRange();
				input[0].selection.moveToBookmark(bookmark);
				input[0].selectLeft = input[0].createTextRange();
				input[0].selectLeft.collapse(true);
				input[0].selectLeft.setEndPoint("EndToStart", input[0].selection);
				return input[0].selectLeft.text.length + 1;
			}

			var caretEnd = function () {
				var bookmark = document.selection.createRange().getBookmark();
				input[0].selection = input[0].createTextRange();
				input[0].selection.moveToBookmark(bookmark);
				input[0].selectLeft = input[0].createTextRange();
				input[0].selectLeft.collapse(true);
				input[0].selectLeft.setEndPoint("EndToStart", input[0].selection);
				return input[0].selectLeft.text.length + ((input[0].selection.text.length == 0) ? 1 : input[0].selection.text.length);
			}

			var handleKey = function(e) {
				var e = e || window.event;
				var key = e.charCode || e.keyCode;

				if (key == 13) return true;
				if (key > 8 && key < 46 && key != 32) { return false; }

				if (loading == false) { triggerLoad(); }
				//if (options.visible) { jQuery(lkup, inputbox).show(); }
			};

			jQuery(input).keyup(handleKey);
			jQuery(input).keydown(handleSpecials);
			jQuery(inputbox).bind("typeahead_configure", function() { jQuery.extend(options, arguments[1]); });
			jQuery(inputbox).bind("typeahead_load", function() { triggerLoad(); });
			jQuery(inputbox).bind("typeahead_clear", function() { hideLkup(); });
		};
	})(jQuery);

	jQuery(document).ready(function(){
		loadTypeAhead();
	});

	function loadTypeAhead(){
		var service_url = "/webapp/wcs/stores/servlet/LWTypeAheadCmd";

		if (jQuery('#SearchForm #Ntk').length > 0){
			jQuery('#search').typeahead({
				field:'Keyword'
				,url:service_url
				,dataType:'jsonp'
				,onDefaultEnter: function(e){
					if (jQuery('#SearchForm').length > 0){
						jQuery('#SearchForm').submit();
					}
				}
				,onSelectedItem: function(index, char_count, chars_typed, val, e){
					var e = e || window.event;
					var key = e.charCode || e.keyCode;
					if (key != 39){ // Do not sumbit if right arrow is used
						jQuery('#search').typeahead_clear();
						if (jQuery('#SearchForm').length > 0){
							var tahType = 'Keyword';
							switch (jQuery('#SearchForm select#Ntk option:selected').val()){
								case "Keyword":
									tahType = 'keyword';
									break;
								case "Title":
									tahType = 'title';
									break;
								case "Product":
									tahType = 'isbn';
									break;
								case "Author":
									tahType = 'author';
									break;
							}
							jQuery('#SearchForm').submit();
						}
					}
				}
			});
			setupConfig();
			jQuery('#SearchForm #Ntk').bind('change', function(){
				setupConfig();
				jQuery('#search').typeahead_load();
			});
		}else{
			jQuery('#search').typeahead({
				field:'sp'
				,url:service_url
				,postData:{
					'type':'keyword'
					,'format':'jsonp'
					,'ref':'com'
				}
				,dataType:'jsonp'
				,onDefaultEnter: function(e){
					if (checkForm(document.SearchForm)){
						jQuery('#SearchForm').submit();
					}
				}
				,onSelectedItem: function(index, char_count, chars_typed, val, e){
					var e = e || window.event;
					var key = e.charCode || e.keyCode;
					if (key != 39){ // Do not sumbit if right arrow is used
						jQuery('#search').typeahead_clear();
						if (checkForm(document.SearchForm)){
							jQuery('#SearchForm').submit();
						}
					}
				}
			});
		}
		jQuery(document).bind('click', function(){
			jQuery('#search').typeahead_clear();
		});
	}

	function setupConfig(){
		switch (jQuery('#SearchForm select#Ntk option:selected').val()){
			case "Keyword":
				jQuery('#search').typeahead_configure({
					postData:{'type':'keyword','format':'jsonp','ref':'com'}
					,onLoadList: function(filter){return true;}
				});
				break;
			case "Title":
				jQuery('#search').typeahead_configure({
					postData:{'type':'title','format':'jsonp','ref':'com'}
					,onLoadList: function(filter){return true;}
				});
				break;
			case "Product":
				jQuery('#search').typeahead_configure({
					postData:{'type':'isbn','format':'jsonp','ref':'com'}
					,onLoadList: function(filter){return false;}
				});
				break;
			case "Author":
				jQuery('#search').typeahead_configure({
					postData:{'type':'author','format':'jsonp','ref':'com'}
					,onLoadList: function(filter){return true;}
				});
				break;
		};
	}

	function searchSort(sortUrl){
		location.href = sortUrl;
	}

	function clearSearchType(){
		if (jQuery('[name=type]').length > 0){
			jQuery('[name=type]').val('');
		}
	}



	/* 1.4 PRODUCT LIST ---------------------------------------------------------------------- */
	/* lwProductList.js */

	jQuery().ready( function () {

		var minicart = jQuery("div#cart");
		var cartRefreshMessage = jQuery("#cartRefreshMessage").val();

		jQuery("div[class='added']").each( function(index, added_item_div) {
			var parent_form = jQuery(added_item_div).parents("form:first");
			var unadded_item_div = jQuery(added_item_div).next("div[class='not_added']");
			var button = jQuery(unadded_item_div).children("button");
			var added_quantity_span = jQuery(added_item_div).find("span[name='quantity']");
			var unadded_quantity_input = jQuery(unadded_item_div).find("input[name='quantity_1']");

			jQuery(parent_form).submit( function() {

				// Disable the button to prevent multiple clicks
				jQuery(button).addClass("disabled").attr("disabled", "disabled");

				// Clear any previous error messages
				jQuery("div#message").replaceWith("<div id='message'> </div>");

				// Call the item add command
				var data = jQuery(parent_form).serialize();
				jQuery.post("/webapp/wcs/stores/servlet/OrderItemAdd?URL=AjaxOrderItemAddView&errorViewName=AjaxOrderItemAddView", data, function(result) {
					if (result.indexOf('LIFEWAY_AJAX_SUCCESS') == -1) {
						// Display add to cart errors, if any
						jQuery("div#message").replaceWith(result);
					} else {
						// Toggle display elements
						var quantity = jQuery(unadded_quantity_input).val();
						jQuery(added_quantity_span).replaceWith(quantity);
						jQuery(added_item_div).show();
						jQuery(unadded_item_div).hide();

						objOmni.lw2AddCartItem(parent_form[0].productNum.value, parent_form[0].itemNum.value, getQtyInCart());

						// Update the minicart, failing silently if it doesn't work
						jQuery(minicart).html("<span>"+cartRefreshMessage+"</span>");
						jQuery.ajax({
							url: '/webapp/wcs/stores/servlet/MiniCartDisplayAjax',
							cache: false,
							dataType: "html",
							success: function(data) {
								jQuery(minicart).html(data);
							}
						});
					}
				});
				return false;
			})
		});
	});

	function getQtyInCart() {
		var amount = jQuery("span[class='amount']").text();
		var arrAmount = amount.split(" ");
		var qtyInCart = arrAmount[0].replace("(", "");
		if (qtyInCart.toString().search(/^[0-9]+$/) != 0) {
			qtyInCart = 1;
		}
		return qtyInCart;
	}

	function loadResultsPage(url, pageSize) {
		location.href = url + "&Sz=" + pageSize;
	}

	function loadResultsPageSize(url) {
		location.href = url;
	}



	/* 1.5 WIDGETS ---------------------------------------------------------------------- */

		/* 1.5.1 ROTATOR ---------------------------------------------------------------------- */
		// plugin lwRotator()
		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the media elements
					// and a couple of other things
					var settings = {
						'interval'	: 6750,
						'fade'		: 1200,
						'fadeclick' : 300
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);
						var $rotate_list = $this.find('ul');
						var rotatorIsPlaying = true;

						// set video hero boolean
						var hasVideoHero = false;
						if($this.find(".video-hero").length){
							hasVideoHero = true;
							var bcVideoHero;
						}

						// do the actual rotation
						function rotate(event, link) {

							var $currentAdRef = $rotate_list.children("li.current");
							var currentAdLink = $currentAdRef.children('a').attr('href');
							var $currentAd = $("#rotator .hero" + currentAdLink);
							var $nextAdRef;
							var fadeSetting = settings.fade;

							if (event === "click") {
								$nextAdRef = link.parent("li");
								fadeSetting = settings.fadeclick;
							} else {
								$nextAdRef = $currentAdRef.next("li");
								if ($nextAdRef.length === 0) {
									$nextAdRef = $rotate_list.children("li:first");
								}
							}
							var nextAdLink = $nextAdRef.children('a').attr('href');
							var $nextAd = jQuery("#rotator .hero" + nextAdLink);

							// check for video hero on current
							if(hasVideoHero && $currentAd.hasClass("video-hero")){
								// check for brightcove object and pause it
								if(typeof(bcVideoHero) == "object" && typeof(bcVideoHero.pause) == "function"){
									bcVideoHero.pause();
								}
							}

							// handle fade & layering
							$currentAd.stop(false, true).css("z-index","1");
							$nextAd.css("opacity","0").css("z-index","2").fadeTo(fadeSetting,1,function(){
								$currentAd.css("z-index","0");
							});

							$currentAdRef.removeClass("current");
							$nextAdRef.addClass("current");

						}

						// start the timer
						var rotateTimer = setInterval(rotate, settings.interval);

						// create and set the functionality for the manual pause link
						$('<a href="#" id="rotate_link" class="play">pause</a>').appendTo(this).click(function(e){
							e.preventDefault();
							if(rotatorIsPlaying){
								jQuery(this).removeClass("play").addClass("pause").text("play");
								clearInterval(rotateTimer);
								rotatorIsPlaying = false;
							}else{
								jQuery(this).removeClass("pause").addClass("play").text("pause");
								rotatorIsPlaying = true;
								rotate();
								rotateTimer = setInterval(rotate, settings.interval);
							}
						});

						// set the functionality for clicking on the menu items
						$rotate_list.find("a").click(function(e) {
							e.preventDefault();
							if (!$(this).parent().hasClass("current")) {
								if (rotatorIsPlaying) {
									clearInterval(rotateTimer);
									rotateTimer = setInterval(rotate, settings.interval);
								}
								rotate(e.type, $(this));
							}
						});

						if(hasVideoHero){
							// initialize video hero, this is set as a callback in the brightcove player snippet
							window.initVideoHero = function(experienceId) {

							    var bc = brightcove.api.getExperience(experienceId);
							    bcVideoHero = bc.getModule(brightcove.api.modules.APIModules.VIDEO_PLAYER);

							    // when video is played, stop the rotator
							    bcVideoHero.addEventListener(brightcove.api.events.MediaEvent.PLAY, function(){

								    // alert("play was clicked!");

								    if(rotatorIsPlaying){
									clearInterval(rotateTimer);
									rotatorIsPlaying = false;
									jQuery("#rotate_link").removeClass("play").addClass("pause").text("play");
								    }
							    });
							}
						}

					});
				}
			};

			$.fn.lwRotator = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwRotator');
				}
			};
		})(jQuery);



		/* 1.5.2 SLIDER ---------------------------------------------------------------------- */
		// plugin lwSlider()

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the slider elements
					// and the number of items that should be visible
					var col_with_item_num = 0;
					if($('.col_full .slider').length)
						{ col_with_item_num = 5;	}
					else
						{ col_with_item_num = 4;	}

					var settings = {
						'carouselVisibleItems'	: col_with_item_num,
						'carouselBox'			: '.window'
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set initial variables
						var $this = $(this);
						var carouselItems = $this.find('li').length;

						// setup the slide functionality if there are enough items in the widget
						if (carouselItems > settings.carouselVisibleItems) {
							// set some more variables
							var carouselBox = $this.find(settings.carouselBox);
							var carousel = $this.find('ul');

							// set carousel width
							var itemWidth = carousel.find("li:first").outerWidth();
							var carouselWidth = itemWidth * carouselItems;
							carousel.width(carouselWidth);

							// create scroll links and set click functionality
							// scroll right button
							$('<div class="rotate right"><a href="#">Rotate Right</a></div>')
							.appendTo(this)
							.click(function(e) {
								e.preventDefault();
								var currentScroll = carouselBox.scrollLeft();
								var newScroll = Math.floor(currentScroll + (itemWidth * settings.carouselVisibleItems));
								// scroll, then hide the right scroll button if we are all the way to the right
								carouselBox.stop().animate({
								    scrollLeft : newScroll
								  }, 500, function() {
									if (newScroll >= carouselWidth - (itemWidth * settings.carouselVisibleItems)) {
										$this.find("div.rotate.right a").hide();
									}
								});
								// make sure the left scroll button is visible now that we have scrolled to the right
								$this.find("div.rotate.left a").show();
							});
							// scroll left button
							$('<div class="rotate left"><a href="#">Rotate Left</a></div>')
							.appendTo(this)
							.click(function(e) {
								e.preventDefault();
								var currentScroll = carouselBox.scrollLeft();
								var newScroll = Math.ceil(currentScroll - (itemWidth * settings.carouselVisibleItems));
								// scroll, then hide the left scroll button if we are all the way to the left
								carouselBox.stop().animate({
								    scrollLeft : newScroll
								  }, 500, function() {
									if (newScroll <= 0) {
										$this.find("div.rotate.left a").hide();
									}
								});
								// make sure the right scroll button is visible now that we have scrolled to the left
								$this.find("div.rotate.right a").show();
							})
							// we're going to initially hide the left scroll button because the slider is scrolled all the way to the left at initiation
							.find("a").hide();
						}
					});
				}
			};

			$.fn.lwSlider = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwSlider');
				}
			};
		})(jQuery);



		/* 1.5.3 SLIDESHOW ---------------------------------------------------------------------- */
		// plugin lwSlideshow()

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the slideshow elements
					// and a couple of other things
					var settings = {
						'slide'		: '.slide',
						'primary'	: '.primary',
						'filmStrip'	: '.film_strip',
						'interval'	: '3500'
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);
						var $slideBox = $this.find(settings.slide);
						var $primarySlide = $slideBox.find(settings.primary);
						var $filmStrip = $this.find(settings.filmStrip);
						var $slideList = $filmStrip.find('ul');
						var $first = $slideList.children("li:first");
						var $next = $slideList.children("li:eq(1)");
						var $previous = $slideList.children("li:last");

						// HTML manipulation - extra classes and elements
						$first.addClass('current');
						// create a holding div for the next image
						$slideBox.append('<div class="next_holder"><img src="'+$next.children("a").attr("href")+'" alt="'+$next.children("img").attr("alt")+'"></div>');
						var $nextHolder = $slideBox.find('.next_holder');
						// create a holding div for the previous image
						$slideBox.append('<div class="previous_holder"><img src="'+$previous.children("a").attr("href")+'" alt="'+$previous.children("img").attr("alt")+'"></div>');
						var $previousHolder = $slideBox.find('.previous_holder');
						// create current item frame
						$this.append('<div class="frame"></div>');
						var $frame = $this.find('.frame');

						// calculations, dimensions and such
						var slideItems = $slideList.find("li").length;
						var slideBoxWidth = $slideBox.outerWidth();
						var slideWidth = $first.outerWidth(true);
						var frameOffset = ($frame.outerWidth(true) - $first.innerWidth())/2;
						var slideScroll = "yes";
						// see if the film stip should rotate based on the number of items
						if (slideItems <= (slideBoxWidth+12)/slideWidth) {
							slideScroll = "no";
							// if it shouldn't rotate, we need to reset some CSS rules
							$slideList.css({'width' : 'auto', 'margin' : '0 auto', 'display' : 'inline-block'});
						}
						// set the initial position of the film strip
						if (slideScroll === "yes") {
							// we need to scroll it by the width of an item in the film strip
							// the width is calculated above
							$filmStrip.scrollLeft(slideWidth);
						}
						// position the frame
						var firstPosition = $first.position();
						var framePosition = "-9999";
						if (firstPosition.left !== -slideWidth) {
							framePosition = firstPosition.left-frameOffset;
						}
						$frame.css({'left' : framePosition});

						// do the actual rotation
						function rotate(direction) {
							// set all the variables (remember, some are different for forward and reverse)
							var $current, $listEnd, $next, $onDeck, nextHeight, scroll, $nextSequencedHolder, $previousSequencedHolder;
							$current = $slideList.children("li.current");
							// set reverse variables
							if (direction === "reverse") {
								$listEnd = $slideList.children("li:last");
								$next = $current.prev("li");
								if ($next.length === 0) {
									$next = $listEnd;
								}
								$onDeck = $next.prev("li");
								if ($onDeck.length === 0) {
									$onDeck = $listEnd;
								}
								nextHeight = $previousHolder.height();
								scroll = 0;
								$nextSequencedHolder = $previousHolder;
								$previousSequencedHolder = $nextHolder;
							// set forward variables
							} else {
								$listEnd = $slideList.children("li:first");
								$next = $current.next("li");
								if ($next.length === 0) {
									$next = $listEnd;
								}
								$onDeck = $next.next("li");
								if ($onDeck.length === 0) {
									$onDeck = $listEnd;
								}
								nextHeight = $nextHolder.height();
								scroll = slideWidth*2;
								$nextSequencedHolder = $nextHolder;
								$previousSequencedHolder = $previousHolder;
							}

							// Animation
							// change the size of the slide container if the new image is a different size
							$slideBox.stop().animate({
								height : nextHeight
							}, 500);
							// scroll the film strip if there are enough elements to allow for scrolling
							if (slideScroll === "yes") {
								$filmStrip.stop().animate({
								    scrollLeft : scroll
								}, 500, function() {
									// move the last (or first) item to the other end of the list
									$listEnd.remove();
									if (direction === "reverse") {
										$slideList.prepend($listEnd);
									} else {
										$slideList.append($listEnd);
									}
									// reset the scroll once the last element has been moved
									$filmStrip.scrollLeft(slideWidth);
								});
							}
							// fade-in the new large image
							$nextSequencedHolder.stop(false, true).fadeIn("slow", function() {
								$slideBox.height("auto");
								$previousSequencedHolder.html($primarySlide.children("img"));
								$primarySlide.html($nextSequencedHolder.children("img"));
								$nextSequencedHolder.hide().html('<img src="'+$onDeck.children("a").attr("href")+'" alt="'+$onDeck.children("img").attr("alt")+'">');
							});

							// position the frame
							var position = $next.position();
							// if we are scrolling we have to add some additional space for the left item in the list that can't be seen
							var slideOff = 0;
							if (slideScroll === "yes") {
								slideOff = slideWidth;
							}
							var framePosition;
							// if position is 0, we hide the frame completely when scrolling
							if (position.left === 0) {
								if (slideScroll === "yes") {
									framePosition = -9999;
								} else {
									framePosition = -frameOffset;
								}
							} else {
								if (direction === "reverse") {
									framePosition = position.left+slideOff-frameOffset;
								} else {
									framePosition = position.left-slideOff-frameOffset;
								}
							}
							// if the frame is near (but outside) the boundaries of the container, we need to go ahead and hide it completely
							if (direction === "reverse") {
								if (framePosition > slideBoxWidth) {
									framePosition = -9999;
								}
							} else {
								if (framePosition < -frameOffset) {
									framePosition = -9999;
								}
							}
							$frame.css({'left' : framePosition});
							// change out the 'current' class
							$current.removeClass("current");
							$next.addClass("current");
						}

						// start the rotator timer
						var rotateTimer = setInterval(rotate, settings.interval);

						// create and set the functionality for the manual links
						$('<div class="buttons"></div>').appendTo($this).hide();
						var $buttons = $this.find('.buttons');
						// play/pause
						$('<p class="play_button"><a href="#" class="play">pause</a></p>').appendTo($buttons).toggle(function() {
							jQuery(this).children('a').removeClass("play").addClass("pause").text("play");
							clearInterval(rotateTimer);
						}, function() {
							jQuery(this).children('a').removeClass("pause").addClass("play").text("pause");
							rotate();
							rotateTimer = setInterval(rotate, settings.interval);
						});
						// forward
						$('<p class="next_link"><a href="#">rotate to next</a></p>').appendTo($buttons).click(function(e) {
							e.preventDefault();
							var play_state = $this.find('.play_button a').attr('class');
							if (play_state === "play") {
								clearInterval(rotateTimer);
								rotateTimer = setInterval(rotate, settings.interval);
							}
							rotate();
						});
						// reverse
						$('<p class="previous_link"><a href="#">rotate to previous</a></p>').appendTo($buttons).click(function(e) {
							e.preventDefault();
							var play_state = $this.find('.play_button a').attr('class');
							if (play_state === "play") {
								clearInterval(rotateTimer);
								rotateTimer = setInterval(rotate, settings.interval);
							}
							rotate('reverse');
						});
						// show and hide
						$this.hover(
							function () {
								$buttons.fadeIn("slow");
							},
							function () {
								$buttons.fadeOut("slow");
							}
						);

						// click functionality
						$slideList.find("a").live("click", function(e) {
							e.preventDefault();
							// set variables
							var $current = $slideList.children("li.current");
							var $clicked = $(this).closest('li');
							var $previous = $clicked.prev('li');
							var $onDeck = $clicked.next('li');
							if ($onDeck.length === 0) {
								$onDeck = $slideList.children("li:first");
							}

							// set frame position
							var position = $clicked.position();
							$(this).closest('.slideshow').find('.frame').css({'left' : position.left-frameOffset});

							// swap out what is in the nextHolder to what was clicked on
							$nextHolder.html('<img src="'+$clicked.children("a").attr("href")+'" alt="'+$clicked.children("img").attr("alt")+'">');
							var nextHeight = $nextHolder.height();
							// Animation
							// change the size of the slide container if the new image is a different size
							$slideBox.stop().animate({
								height : nextHeight
							}, 500);
							// fade-in the new large image
							$nextHolder.stop(false, true).fadeIn("slow", function() {
								$slideBox.height("auto");
								$previousHolder.html('<img src="'+$previous.children("a").attr("href")+'" alt="'+$previous.children("img").attr("alt")+'">');
								$primarySlide.html($nextHolder.children("img"));
								$nextHolder.hide().html('<img src="'+$onDeck.children("a").attr("href")+'" alt="'+$onDeck.children("img").attr("alt")+'">');
							});
							// change out the 'current' class
							$current.removeClass("current");
							$clicked.addClass("current");
							// reset the timer, unless we are paused
							var play_state = $('.slideshow .play_button a').attr('class');
							if (play_state === "play") {
								clearInterval(rotateTimer);
								rotateTimer = setInterval(rotate, settings.interval);
							}
						});

						// preload large images
						$slideList.find("a").lwSlideshow('cache');
				    });
				},
			    cache : function() {
					var cache = [];
					return this.each(function() {
						var cacheImage = document.createElement('img');
						cacheImage.src = $(this).attr("href");
						cache.push(cacheImage);
					});
				}
			};

			$.fn.lwSlideshow = function(method) {
				// Method calling logic
			    if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
			    } else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
			    } else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwSlideshow');
			    }
			};
		})(jQuery);



		/* 1.5.4 MEDIA ---------------------------------------------------------------------- */
		// plugin lwMedia()

		(function($){
			var methods = {
				init : function(options) {
					// use settings to hold the default class names of the media elements
					// and a couple of other things
					var settings = {
						'firstItem'		: '.media_item:eq(0)',
						'firstListItem'	: '.nav a:eq(0)',
						'listItems'		: '.nav a'
					};

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						if (options) {
							$.extend(settings, options);
						}

						// set variables
						var $this = $(this);
						var $firstItem = $this.find(settings.firstItem);
						var $firstListItem = $this.find(settings.firstListItem);
						var $listItems = $this.find(settings.listItems);

						// set classes for initial styling (items without a class of "on" should be hidden by the css)
						$firstItem.addClass("on");
						$firstListItem.addClass("on");

						if(typeof(VideoJS) === 'function') {
							$('.media .content video').VideoJS();
						}

						// resize media content container to height of tallest div
						var maxHeight = 0;
						$('.media_item').each(function(){
							maxHeight = Math.max(maxHeight, $(this).height());
						});
						$('.media .content').height(maxHeight);

						// detect how many videos are in media
						// used for pausing videos when clicking new nav item
						navCount = $('.nav li.video').size();
						vidCount = parseInt(navCount);

						$listItems.click(function(e){
							e.preventDefault();
							// record the index of the list item that was clicked
							var navIndex = $listItems.index(this);

							// remove the "on" class from the elements that currently have it
							$this.find('.on').removeClass("on");

							// locate the media item with the same index as the list item
							// add the clicked list item to the selection
							// and add the "on" class to both
							$this.find('.media_item:eq('+ navIndex +')').add(this).addClass("on");

							// pause audio player if it's there
							$('.media .jplayer').jPlayer("pause");

							// pause each video when clicking on new navigation item
							var i=0;
							for (i=1;i<=vidCount;i++)
							{
								$('.media_item video')[i-1].player.pause();
							}
						});
					});
				}
			};

			$.fn.lwMedia = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwMedia');
				}
			};
		})(jQuery);



		/* 1.5.5 MODAL ---------------------------------------------------------------------- */
		// plugin lwModal()
		// beware the video-js stuff when you update this plugin

		(function($){
			var methods = {
				init : function(options) {
					// we're going to use an array for all of our variables so we can easily pass them from method to method
					var vars = {
						'link'			: $(this).attr('href'),
						'title'			: $(this).attr('title'),
						'rel'			: $(this).attr('rel'),
						'modalData'		: $(this).data(),
						'$modal'		: ''
					}

					return this.each(function() {
						// if options exist, lets merge them with our default settings
						var settings = $.extend({}, $.fn.lwModal.defaults, options);

						// the function that controls the logic for what happens next
						function modalLogic(e) {
							if (e) {
								e.preventDefault();
							}

							// first, let's assign the modal box (if it exists) to a variable
							vars.$modal = $('.'+settings.modalWrap+'[rel="'+vars.link+'"]').filter('[data-modal_life="'+vars.modalData.modal_life+'"]');

							// if the modal already exists, let's fire the toggle method (we're relying on the url being set as the rel value for the modal in the build method to tie the link and the modal box together - we're also making sure the modal_life data attribute is the same as the link to keep the different types of modals segregated)
							if (vars.$modal.length) {
								$(this).lwModal('toggle', vars.$modal);

							// if it doesn't already exist, let's build it
							} else {
								$(this).lwModal('build', settings, vars);
							}
						}

						// fire the function to create the modal the first time through
						modalLogic();

						// now we'll bind a click event to fire the logic function on all following clicks
						$(this).bind('click.modal', modalLogic);
					});
				},
				build : function(settings, vars) {
					return this.each(function() {
						// go ahead and create and show the loading message (so it is in place while the modal is being created - especially important if the message comes from an external page)
						$(this).lwModal('loadingCreate');

						// see if there should be an extra class on the modal
						var extraClass = '';
						if (settings.extraClass) {
							extraClass = ' ' + settings.extraClass;
						}
						// start building the modal box
						vars.$modal = $('<div class="'+settings.modalWrap+extraClass+'" rel="'+vars.link+'" data-modal_life="'+vars.modalData.modal_life+'" data-modal_speed="'+settings.speed+'" style="display:none;"></div>');

						// add the modal to the document
						vars.$modal.appendTo('body');

						// assign all data elements from the calling link to the created modal (we'll use this for persistance rules and other settings later)
						vars.$modal.data(vars.modalData);

						// the function that puts all the pieces together and initiates display of the modal once everything has been loaded
						function modalLoadingComplete() {
							// wrap the body of the modal
							vars.$modal.wrapInner('<div class="'+settings.modalBody+'"></div>');

							// do header/title stuff here
							if (vars.title) {
								vars.$modal.prepend('<div class="'+settings.modalHead+'"><h2 class="title">'+vars.title+'<span class="close close_button"><a href="#">&times;</a></span>'+'</h2></div>');
							}

							// do footer stuff here
							if (!vars.title) {
								vars.$modal.append('<div class="'+settings.modalFoot+'"><p class="close button"><a href="#">Close</a></p></div>');
							}

							// add bgiframe here (if available)
							if (typeof($.fn.bgiframe) === 'function') {
								vars.$modal.bgiframe();
							}

							// build the backdrop if it doesn't exist
							// first, let's assign the backdrop to a variable
							$.fn.lwModal.$backdrop = $('.'+settings.backdrop);
							if (!$.fn.lwModal.$backdrop.length) {
								vars.$modal.lwModal('backdropCreate', settings);
							}

							// fire the show function as the last step of the build
							vars.$modal.lwModal('show', settings, vars);

							// bind click functionality for close buttons
							vars.$modal.find(".close a, a.close").bind('click.modal', function(e) {
								e.preventDefault();
								vars.$modal.lwModal('hide');
							});

							// initialise VideoJS if modal has video element - this should go away when video-js is removed
							if(vars.$modal.find('.video-js').length){
								if (typeof(VideoJS) === 'function') {
									VideoJS.setup("modal_video"+count);
								}
							}
						}

						// add the target html to the modal body
						// look to see if the link is to an element in this page
						if (vars.link.match(/^#/i)) {
							vars.$modal.append($(vars.link).html());
							modalLoadingComplete();
						// Deal with external links
						} else {
							// See if a target box ID is specified in the rel attribute of the link, and only load that box if it is
							if (vars.rel) {
								vars.$modal.load(vars.link+' #'+vars.rel, modalLoadingComplete);
							} else {
								vars.$modal.load(vars.link, modalLoadingComplete);
							}
						}
					});
				},
				toggle : function(modal) {
					return this.each(function() {
						// check to see if it is visible
						// if it is, do the logic for hiding or removing it
						if (modal.is(':visible')) {
							modal.lwModal('hide');
						// if it's not visible, let's fire the show function
						} else {
							modal.lwModal('show');
						}
					});
				},
				show : function() {
					return this.each(function() {
						// first, let's hide any currently visible modal boxes
						$('.'+$.fn.lwModal.defaults.modalWrap).filter(':visible').each(function() {
							$(this).lwModal('hide');
						});
						// then, let's remove and currently visible loading graphics
						$('.loading').lwModal('loadingRemove');

						// then, turn on the backdrop
						$.fn.lwModal.$backdrop.lwModal('backdropShow');

						// finally, display the modal
						var windowHeight = $(window).height();
						var modalHeight = $(this).outerHeight();
						// show the modal centered if there is enough room
						if (modalHeight <= (windowHeight-20)) {
							var scrollHeight = $(document).scrollTop();
							$(this).css({
								'margin-top': '-'+modalHeight/2+'px',
								position: 'absolute',
								top: scrollHeight+(windowHeight/2)
							});
						// position it at the top if there isn't enough room
						} else {
							var scrollHeight = $(document).scrollTop();
							$(this).css({
								'margin-top': '20px',
								position: 'absolute',
								top: scrollHeight
							});
						}
						// fade the modal in
						// TODO: add setting for fadeIn speed, or make it css
						$(this).fadeIn($(this).data('modal_speed'));
					});
				},
				hide : function(remove) {
					return this.each(function() {
						// first, turn off the backdrop
						$.fn.lwModal.$backdrop.lwModal('backdropHide');

						// then, hide the modal
						$(this).fadeOut($(this).data('modal_speed'), function() {
							if ((!$(this).data('modal_life') || $(this).data('modal_life').toLowerCase() !== 'persist' || remove === 'remove') && remove !== 'persist') {
								$(this).remove();
							}
						});
					});
				},
				backdropCreate : function(settings) {
					return this.each(function() {
						// build the backdrop
						$.fn.lwModal.$backdrop = $('<div class="'+settings.backdrop+'" style="display:none;"></div>');

						// insert the backdrop
						$.fn.lwModal.$backdrop.insertBefore(this);

						// setup behavior so that a click on the backdrop hides the visible modal
						$.fn.lwModal.$backdrop.click(function() {
							$('.'+settings.modalWrap).filter(':visible').each(function() {
								$(this).lwModal('hide');
							});
						});
					});
				},
				backdropShow : function() {
					return this.each(function() {
						$(this).css({
							height: $(document).height()
						}).fadeIn($.fn.lwModal.defaults.speed);
					});
				},
				backdropHide : function() {
					return this.each(function() {
						$(this).fadeOut($.fn.lwModal.defaults.speed);
					});
				},
				loadingCreate : function() {
					return this.each(function() {
						$('<div class="loading" style="display:none;"></div>').appendTo('body').fadeIn($.fn.lwModal.defaults.speed);
					});
				},
				loadingRemove: function() {
					return this.each(function() {
						$(this).stop().remove();
					});
				}
			};

			$.fn.lwModal = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwModal');
				}
			};

			// Let's setup defaults that will be available to all of our methods
			// use settings to hold the default class names of the modal elements we'll be creating later
			$.fn.lwModal.defaults = {
				'modalWrap'		: 'modal_message',
				'modalHead'		: 'modal_header',
				'modalBody'		: 'modal_body',
				'modalFoot'		: 'modal_footer',
				'backdrop'		: 'modal_overlay',
				'speed'			: 400,
				'extraClass'	: ''
			};
		})(jQuery);


		/* 1.5.6 PLUCK STARS FIX ---------------------------------------------------------------------- */

		// jQuery( '.pluck-review-starsOutput em' ).each(function( index ) {
		//   jQuery(this).css('left',jQuery(this).text()/5*120+'px');
		// });



	/* 1.6 ENDECA PREVIEW ---------------------------------------------------------------------- */

	function changeJDomain(){
		var jDomain = "";
		var domainKey = "jDomain";
		var queryJDomain = getQueryStringParam(domainKey);
		if (queryJDomain.length > 0){
			jDomain = queryJDomain;
			createCookie(domainKey, jDomain);
			//alert('found jDomain via the querystring ['+jDomain+']');
		}else{
			var cookieJDomain = readCookie(domainKey);
			if (cookieJDomain != null && cookieJDomain.length > 0){
				jDomain = cookieJDomain;
				//alert('found jDomain via the cookie ['+jDomain+']');
			}
		}
		if (jDomain.length > 0){
			//alert('jDomain = ['+jDomain+']')
			document.domain = jDomain;
			//alert('set document.domain ['+document.domain+']');
		}
	}
	if (typeof(createCookie) === 'function' && typeof(readCookie) === 'function' && typeof(getQueryStringParam) === 'function') {
		changeJDomain();
		jQuery(window).load( function () {
			var resizeFrame = false;
			var domainKey = "jDomain";
			var queryJDomain = getQueryStringParam(domainKey);
			if (queryJDomain.length > 0){
				resizeFrame = true;
			}else{
				var cookieJDomain = readCookie(domainKey);
				if (cookieJDomain != null && cookieJDomain.length > 0){
					resizeFrame = true;
				}
			}
			if (resizeFrame){
				if(self==parent){
					return false;
				}else if(!document.getElementById && !document.all){
					return false;
				}

				var framePageHeight = jQuery('body')[0].scrollHeight + 350;
				parent.document.getElementById('refApp').style.height=framePageHeight+'px';
			}
		});
	}


	/* 1.7 FORMS ---------------------------------------------------------------------- */

		/* 1.7.1 PLACEHOLDER ---------------------------------------------------------------------- */
		// plugin lwPlaceholder()

		(function($){
			var methods = {
				init : function() {
					return this.each(function() {
						// set variables
						var $this = $(this);
						var placeholder = $this.attr('placeholder');

						// if no value is set, set it to the placeholder text
						// then, setup the rest of the functionality
						// we'll toggle the 'placeholder' class on the input for styling
						if ($this.val() === '') {
							$this.val(placeholder).addClass('placeholder');

							// remove the placeholder text
							$this.focus(function() {
								if ($this.val() === placeholder) {
									$this.val('').removeClass('placeholder');
								}
							})
							// add the placeholder text back if there isn't anything in the field
							.blur(function() {
								if ($this.val() === '') {
									$this.val(placeholder).addClass('placeholder');
								}
							});

							// remove the field text if it is the same as the placeholder so that validation scripts will run properly
							$this.closest('form').submit(function() {
								if ($this.val() === placeholder) {
									$this.val('');
								}
							});
						}
					});
				}
			};

			$.fn.lwPlaceholder = function(method) {
				// Method calling logic
				if (methods[method]) {
					return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
				} else if (typeof method === 'object' || ! method) {
					return methods.init.apply(this, arguments);
				} else {
					$.error('Method ' +  method + ' does not exist on jQuery.lwPlaceholder');
				}
			};
		})(jQuery);



		/* 1.7.2 URL SELECTOR ---------------------------------------------------------------------- */
		// plugin lwSelectGo()

		(function($){
			$.fn.lwSelectGo = function() {
				return this.each(function() {
					// set variables
					var $this = $(this);

					// find the url from the value of the selected option and send the window to that url
					$this.change(function() {
						var selectUrl = $this.find('option:selected').val();
						if (selectUrl !== "") {
							window.location.href = selectUrl;
						}
					});
				});
			};
		})(jQuery);



	/* 1.8 INTERNATIONAL ADDRESS VALIDATION ON EDIT PAYMENT PAGE ---------------------------- */
	// start of internation address state/province validations

	function onChangeCountry() {
		var currentCountryCode = jQuery('#edit_cc_address_country').val();

		if(currentCountryCode != 'US' && currentCountryCode != 'CA') {
			jQuery('#stateRequired, #zipCodeRequired').hide();
	        jQuery('#edit_cc_address_state').rules("remove");
	        jQuery('#edit_cc_address_zip').rules("remove");
	        jQuery('#stateDiv').children('p.error').remove();
	        jQuery('#zipCodeDiv').children('p.error').remove();
	        jQuery('#edit_cc_address_state').removeClass("error");
	        jQuery('#edit_cc_address_zip').removeClass("error");
		} else {
			jQuery('#stateRequired, #zipCodeRequired').show();
	        jQuery('#edit_cc_address_state').rules("add", {
	        	required: true,
	        	messages: {
	        		required: stateRequiredMessage
	        	}
	        });
	        jQuery('#edit_cc_address_zip').rules("add", {
	        	required: true,
	        	messages: {
	        		required: zipRequiredMessage
	        	}
	        });
	        jQuery('#edit_cc_address_zip, #edit_cc_address_state').blur(function() {
				  jQuery(this).valid();
			});
	        jQuery('#edit_cc_address_country').blur(function(){
	        	jQuery('#edit_cc_address_zip').valid();
	        	jQuery('#edit_cc_address_state').valid();
	        });
		}
	}



/* 2.3RD-PARTY PLUGINS
---------------------------------------------------------------------- */

	/* 2.1 HOVERINTENT ---------------------------------------------------------------------- */
	/* jquery.hoverIntent.js */

	/**
	* hoverIntent is similar to jQuery's built-in "hover" function except that
	* instead of firing the onMouseOver event immediately, hoverIntent checks
	* to see if the user's mouse has slowed down (beneath the sensitivity
	* threshold) before firing the onMouseOver event.
	*
	* hoverIntent r6 // 2011.02.26 // jQuery 1.5.1+
	* <http://cherne.net/brian/resources/jquery.hoverIntent.html>
	*
	* hoverIntent is currently available for use in all personal or commercial
	* projects under both MIT and GPL licenses. This means that you can choose
	* the license that best suits your project, and use it accordingly.
	*
	* // basic usage (just like .hover) receives onMouseOver and onMouseOut functions
	* $("ul li").hoverIntent( showNav , hideNav );
	*
	* // advanced usage receives configuration object only
	* $("ul li").hoverIntent({
	*	sensitivity: 7, // number = sensitivity threshold (must be 1 or higher)
	*	interval: 100,   // number = milliseconds of polling interval
	*	over: showNav,  // function = onMouseOver callback (required)
	*	timeout: 0,   // number = milliseconds delay before onMouseOut function call
	*	out: hideNav    // function = onMouseOut callback (required)
	* });
	*
	* @param  f  onMouseOver function || An object with configuration options
	* @param  g  onMouseOut function  || Nothing (use configuration options object)
	* @author    Brian Cherne brian(at)cherne(dot)net
	*/
	(function($) {
		$.fn.hoverIntent = function(f,g) {
			// default configuration options
			var cfg = {
				sensitivity: 7,
				interval: 100,
				timeout: 0
			};
			// override configuration options with user supplied object
			cfg = $.extend(cfg, g ? { over: f, out: g } : f );

			// instantiate variables
			// cX, cY = current X and Y position of mouse, updated by mousemove event
			// pX, pY = previous X and Y position of mouse, set by mouseover and polling interval
			var cX, cY, pX, pY;

			// A private function for getting mouse position
			var track = function(ev) {
				cX = ev.pageX;
				cY = ev.pageY;
			};

			// A private function for comparing current and previous mouse position
			var compare = function(ev,ob) {
				ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
				// compare mouse positions to see if they've crossed the threshold
				if ( ( Math.abs(pX-cX) + Math.abs(pY-cY) ) < cfg.sensitivity ) {
					$(ob).unbind("mousemove",track);
					// set hoverIntent state to true (so mouseOut can be called)
					ob.hoverIntent_s = 1;
					return cfg.over.apply(ob,[ev]);
				} else {
					// set previous coordinates for next time
					pX = cX; pY = cY;
					// use self-calling timeout, guarantees intervals are spaced out properly (avoids JavaScript timer bugs)
					ob.hoverIntent_t = setTimeout( function(){compare(ev, ob);} , cfg.interval );
				}
			};

			// A private function for delaying the mouseOut function
			var delay = function(ev,ob) {
				ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
				ob.hoverIntent_s = 0;
				return cfg.out.apply(ob,[ev]);
			};

			// A private function for handling mouse 'hovering'
			var handleHover = function(e) {
				// copy objects to be passed into t (required for event object to be passed in IE)
				var ev = jQuery.extend({},e);
				var ob = this;

				// cancel hoverIntent timer if it exists
				if (ob.hoverIntent_t) { ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t); }

				// if e.type == "mouseenter"
				if (e.type == "mouseenter") {
					// set "previous" X and Y position based on initial entry point
					pX = ev.pageX; pY = ev.pageY;
					// update "current" X and Y position based on mousemove
					$(ob).bind("mousemove",track);
					// start polling interval (self-calling timeout) to compare mouse coordinates over time
					if (ob.hoverIntent_s != 1) { ob.hoverIntent_t = setTimeout( function(){compare(ev,ob);} , cfg.interval );}

				// else e.type == "mouseleave"
				} else {
					// unbind expensive mousemove event
					$(ob).unbind("mousemove",track);
					// if hoverIntent state is true, then call the mouseOut function after the specified delay
					if (ob.hoverIntent_s == 1) { ob.hoverIntent_t = setTimeout( function(){delay(ev,ob);} , cfg.timeout );}
				}
			};

			// bind the function to the two event listeners
			return this.bind('mouseenter',handleHover).bind('mouseleave',handleHover);
		};
	})(jQuery);



	/* 2.2 BGIFRAME ---------------------------------------------------------------------- */
	/* jquery.bgiframe.js */

	/*! Copyright (c) 2010 Brandon Aaron (http://brandonaaron.net)
	 * Licensed under the MIT License (LICENSE.txt).
	 *
	 * Version 2.1.2
	 */

	(function($){

	$.fn.bgiframe = ($.browser.msie && /msie 6\.0/i.test(navigator.userAgent) ? function(s) {
	    s = $.extend({
	        top     : 'auto', // auto == .currentStyle.borderTopWidth
	        left    : 'auto', // auto == .currentStyle.borderLeftWidth
	        width   : 'auto', // auto == offsetWidth
	        height  : 'auto', // auto == offsetHeight
	        opacity : true,
	        src     : 'javascript:false;'
	    }, s);
	    var html = '<iframe class="bgiframe"frameborder="0"tabindex="-1"src="'+s.src+'"'+
	                   'style="display:block;position:absolute;z-index:-1;'+
	                       (s.opacity !== false?'filter:Alpha(Opacity=\'0\');':'')+
	                       'top:'+(s.top=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+\'px\')':prop(s.top))+';'+
	                       'left:'+(s.left=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+\'px\')':prop(s.left))+';'+
	                       'width:'+(s.width=='auto'?'expression(this.parentNode.offsetWidth+\'px\')':prop(s.width))+';'+
	                       'height:'+(s.height=='auto'?'expression(this.parentNode.offsetHeight+\'px\')':prop(s.height))+';'+
	                '"/>';
	    return this.each(function() {
	        if ( $(this).children('iframe.bgiframe').length === 0 )
	            this.insertBefore( document.createElement(html), this.firstChild );
	    });
	} : function() { return this; });

	// old alias
	$.fn.bgIframe = $.fn.bgiframe;

	function prop(n) {
	    return n && n.constructor === Number ? n + 'px' : n;
	}

	})(jQuery);



	/* 2.3 JPLAYER ---------------------------------------------------------------------- */
	/* jquery.jplayer.js */

	/*
	 * jPlayer Plugin for jQuery JavaScript Library
	 * http://www.happyworm.com/jquery/jplayer
	 *
	 * Copyright (c) 2009 - 2010 Happyworm Ltd
	 * Dual licensed under the MIT and GPL licenses.
	 *  - http://www.opensource.org/licenses/mit-license.php
	 *  - http://www.gnu.org/copyleft/gpl.html
	 *
	 * Author: Mark J Panaghiston
	 * Version: 1.2.0
	 * Date: 11th July 2010
	 */

	(function($) {

		// Adapted from ui.core.js (1.7.2)
		function getter(plugin, method, args) {
			function getMethods(type) {
				var methods = $[plugin][type] || [];
				return (typeof methods == 'string' ? methods.split(/,?\s+/) : methods);
			}
			var methods = getMethods('getter');
			return ($.inArray(method, methods) != -1);
		}

		// Adapted from ui.core.js (1.7.2) $.widget() "create plugin method"
		// $.data() info at http://docs.jquery.com/Internals/jQuery.data
		$.fn.jPlayer = function(options) {

			var name = "jPlayer";
			var isMethodCall = (typeof options == 'string');
			var args = Array.prototype.slice.call(arguments, 1);

			// prevent calls to internal methods
			if (isMethodCall && options.substring(0, 1) == '_') {
				return this;
			}

			// handle getter methods
			if (isMethodCall && getter(name, options, args)) {
				var instance = $.data(this[0], name);
				return (instance ? instance[options].apply(instance, args) : undefined);
			}

			// handle initialization and non-getter methods
			return this.each(function() {
				var instance = $.data(this, name);

				// constructor
				if(!instance && !isMethodCall) {
					$.data(this, name, new $[name](this, options))._init();
				}

				// method call
				(instance && isMethodCall && $.isFunction(instance[options]) &&
					instance[options].apply(instance, args));
			});
		};

		$.jPlayer = function(element, options) {
			this.options = $.extend({}, options);
			this.element = $(element);
		};

		$.jPlayer.getter = "jPlayerOnProgressChange jPlayerOnSoundComplete jPlayerVolume jPlayerReady getData jPlayerController";

		$.jPlayer.defaults = {
			cssPrefix: "jqjp",
			swfPath: "js",
			volume: 80,
			oggSupport: false,
			nativeSupport: true,
			preload: 'none',
			customCssIds: false,
			graphicsFix: true,
			errorAlerts: false,
			warningAlerts: false,
			position: "absolute",
			width: "0",
			height: "0",
			top: "0",
			left: "0",
			quality: "high",
			bgcolor: "#ffffff"
		};

		$.jPlayer._config = {
			version: "1.2.0",
			swfVersionRequired: "1.2.0",
			swfVersion: "unknown",
			jPlayerControllerId: undefined,
			delayedCommandId: undefined,
			isWaitingForPlay:false,
			isFileSet:false
		};

		$.jPlayer._diag = {
			isPlaying: false,
			src: "",
			loadPercent: 0,
			playedPercentRelative: 0,
			playedPercentAbsolute: 0,
			playedTime: 0,
			totalTime: 0
		};

		$.jPlayer._cssId = {
			play: "jplayer_play",
			pause: "jplayer_pause",
			stop: "jplayer_stop",
			loadBar: "jplayer_load_bar",
			playBar: "jplayer_play_bar",
			volumeMin: "jplayer_volume_min",
			volumeMax: "jplayer_volume_max",
			volumeBar: "jplayer_volume_bar",
			volumeBarValue: "jplayer_volume_bar_value"
		};

		$.jPlayer.count = 0;

		$.jPlayer.timeFormat = {
			showHour: false,
			showMin: true,
			showSec: true,
			padHour: false,
			padMin: true,
			padSec: true,
			sepHour: ":",
			sepMin: ":",
			sepSec: ""
		};

		$.jPlayer.convertTime = function(mSec) {
			var myTime = new Date(mSec);
			var hour = myTime.getUTCHours();
			var min = myTime.getUTCMinutes();
			var sec = myTime.getUTCSeconds();
			var strHour = ($.jPlayer.timeFormat.padHour && hour < 10) ? "0" + hour : hour;
			var strMin = ($.jPlayer.timeFormat.padMin && min < 10) ? "0" + min : min;
			var strSec = ($.jPlayer.timeFormat.padSec && sec < 10) ? "0" + sec : sec;
			return (($.jPlayer.timeFormat.showHour) ? strHour + $.jPlayer.timeFormat.sepHour : "") + (($.jPlayer.timeFormat.showMin) ? strMin + $.jPlayer.timeFormat.sepMin : "") + (($.jPlayer.timeFormat.showSec) ? strSec + $.jPlayer.timeFormat.sepSec : "");
		};

		$.jPlayer.prototype = {
			_init: function() {
				var self = this;
				var element = this.element;

				this.config = $.extend({}, $.jPlayer.defaults, this.options, $.jPlayer._config);
				this.config.diag = $.extend({}, $.jPlayer._diag);
				this.config.cssId = {};
				this.config.cssSelector = {};
				this.config.cssDisplay = {};
				this.config.clickHandler = {};

				this.element.data("jPlayer.config", this.config);

				$.extend(this.config, {
					id: this.element.attr("id"),
					swf: this.config.swfPath + ((this.config.swfPath != "" && this.config.swfPath.slice(-1) != "/") ? "/" : "") + "Jplayer.swf",
					fid: this.config.cssPrefix + "_flash_" + $.jPlayer.count,
					aid: this.config.cssPrefix + "_audio_" + $.jPlayer.count,
					hid: this.config.cssPrefix + "_force_" + $.jPlayer.count,
					i: $.jPlayer.count,
					volume: this._limitValue(this.config.volume, 0, 100),
					autobuffer: this.config.preload != 'none'
				});

				$.jPlayer.count++;

				if(this.config.ready != undefined) {
					if($.isFunction(this.config.ready)) {
						this.jPlayerReadyCustom = this.config.ready;
					} else {
						this._warning("Constructor's ready option is not a function.");
					}
				}

				this.config.audio = document.createElement('audio');
				this.config.audio.id = this.config.aid;
				// The audio element is added to the page further down with the defaults.

				$.extend(this.config, {
					canPlayMP3: !!((this.config.audio.canPlayType) ? (("" != this.config.audio.canPlayType("audio/mpeg")) && ("no" != this.config.audio.canPlayType("audio/mpeg"))) : false),
					canPlayOGG: !!((this.config.audio.canPlayType) ? (("" != this.config.audio.canPlayType("audio/ogg")) && ("no" != this.config.audio.canPlayType("audio/ogg"))) : false),
					aSel: $("#" + this.config.aid)
				});

				$.extend(this.config, {
					html5: !!((this.config.oggSupport) ? ((this.config.canPlayOGG) ? true : this.config.canPlayMP3) : this.config.canPlayMP3)
				});

				$.extend(this.config, {
					usingFlash: !(this.config.html5 && this.config.nativeSupport),
					usingMP3: !(this.config.oggSupport && this.config.canPlayOGG && this.config.nativeSupport)
				});

				var events = {
					setButtons: function(e, playing) {
						self.config.diag.isPlaying = playing;
						if(self.config.cssId.play != undefined && self.config.cssId.pause != undefined) {
							if(playing) {
								self.config.cssSelector.play.css("display", "none");
								self.config.cssSelector.pause.css("display", self.config.cssDisplay.pause);
							} else {
								self.config.cssSelector.play.css("display", self.config.cssDisplay.play);
								self.config.cssSelector.pause.css("display", "none");
							}
						}
						if(playing) {
							self.config.isWaitingForPlay = false;
						}

					}
				};

				var eventsForFlash = {
					setFile: function(e, mp3, ogg) {
						try {
							self._getMovie().fl_setFile_mp3(mp3);
							if(self.config.autobuffer) {
								element.trigger("jPlayer.load");
							}
							self.config.diag.src = mp3;
							self.config.isFileSet = true; // Set here for conformity, but the flash handles this internally and through return values.
							element.trigger("jPlayer.setButtons", false);
						} catch(err) { self._flashError(err); }
					},
					clearFile: function(e) {
						try {
							element.trigger("jPlayer.setButtons", false); // Before flash method so states correct for when onProgressChange is called
							self._getMovie().fl_clearFile_mp3();
							self.config.diag.src = "";
							self.config.isFileSet = false;
						} catch(err) { self._flashError(err); }
					},
					load: function(e) {
						try {
							self._getMovie().fl_load_mp3();
						} catch(err) { self._flashError(err); }
					},
					play: function(e) {
						try {
							if(self._getMovie().fl_play_mp3()) {
								element.trigger("jPlayer.setButtons", true);
							}
						} catch(err) { self._flashError(err); }
					},
					pause: function(e) {
						try {
							if(self._getMovie().fl_pause_mp3()) {
								element.trigger("jPlayer.setButtons", false);
							}
						} catch(err) { self._flashError(err); }
					},
					stop: function(e) {
						try {
							if(self._getMovie().fl_stop_mp3()) {
								element.trigger("jPlayer.setButtons", false);
							}
						} catch(err) { self._flashError(err); }
					},
					playHead: function(e, p) {
						try {
							if(self._getMovie().fl_play_head_mp3(p)) {
								element.trigger("jPlayer.setButtons", true);
							}
						} catch(err) { self._flashError(err); }
					},
					playHeadTime: function(e, t) {
						try {
							if(self._getMovie().fl_play_head_time_mp3(t)) {
								element.trigger("jPlayer.setButtons", true);
							}
						} catch(err) { self._flashError(err); }
					},
					volume: function(e, v) {
						self.config.volume = v;
						try {
							self._getMovie().fl_volume_mp3(v);
						} catch(err) { self._flashError(err); }
					}
				};

				var eventsForHtmlAudio = {
					setFile: function(e, mp3, ogg) {
						if(self.config.usingMP3) {
							self.config.diag.src = mp3;
						} else {
							self.config.diag.src = ogg;
						}
						if(self.config.isFileSet  && !self.config.isWaitingForPlay) {
							element.trigger("jPlayer.pause");
						}
						self.config.audio.autobuffer = self.config.autobuffer; // In case not preloading, but used a jPlayer("load")
						self.config.audio.preload = self.config.preload; // In case not preloading, but used a jPlayer("load")
						if(self.config.autobuffer) {
							self.config.audio.src = self.config.diag.src;
							self.config.audio.load();
						} else {
							self.config.isWaitingForPlay = true;
						}
						self.config.isFileSet = true;
						self.jPlayerOnProgressChange(0, 0, 0, 0, 0);
						clearInterval(self.config.jPlayerControllerId);
						if(self.config.autobuffer) {
							self.config.jPlayerControllerId = window.setInterval( function() {
								self.jPlayerController(false);
							}, 100);
						}
						clearInterval(self.config.delayedCommandId);
					},
					clearFile: function(e) {
						self.setFile("","");
						self.config.isWaitingForPlay = false;
						self.config.isFileSet = false;
					},
					load: function(e) {
						if(self.config.isFileSet) {
							if(self.config.isWaitingForPlay) {
								self.config.audio.autobuffer = true;
								self.config.audio.preload = 'auto';
								self.config.audio.src = self.config.diag.src;
								self.config.audio.load();
								self.config.isWaitingForPlay = false;
								clearInterval(self.config.jPlayerControllerId);
								self.config.jPlayerControllerId = window.setInterval( function() {
									self.jPlayerController(false);
								}, 100);
							}
						}
					},
					play: function(e) {
						if(self.config.isFileSet) {
							if(self.config.isWaitingForPlay) {
								self.config.audio.src = self.config.diag.src;
								self.config.audio.load();
							}
							self.config.audio.play();
							element.trigger("jPlayer.setButtons", true);
							clearInterval(self.config.jPlayerControllerId);
							self.config.jPlayerControllerId = window.setInterval( function() {
								self.jPlayerController(false);
							}, 100);
							clearInterval(self.config.delayedCommandId);
						}
					},
					pause: function(e) {
						if(self.config.isFileSet) {
							self.config.audio.pause();
							element.trigger("jPlayer.setButtons", false);
							clearInterval(self.config.delayedCommandId);
						}
					},
					stop: function(e) {
						if(self.config.isFileSet) {
							try {
								element.trigger("jPlayer.pause");
								self.config.audio.currentTime = 0;
								clearInterval(self.config.jPlayerControllerId);
								self.config.jPlayerControllerId = window.setInterval( function() {
									self.jPlayerController(true); // With override true
								}, 100);

							} catch(err) {
								clearInterval(self.config.delayedCommandId);
								self.config.delayedCommandId = window.setTimeout(function() {
									self.stop();
								}, 100);
							}
						}
					},
					playHead: function(e, p) {
						if(self.config.isFileSet) {
							try {
								element.trigger("jPlayer.load");
								if((typeof self.config.audio.buffered == "object") && (self.config.audio.buffered.length > 0)) {
									self.config.audio.currentTime = p * self.config.audio.buffered.end(self.config.audio.buffered.length-1) / 100;
								} else if(self.config.audio.duration > 0 && !isNaN(self.config.audio.duration)) {
									self.config.audio.currentTime = p * self.config.audio.duration / 100;
								} else {
									throw "e";
								}
								element.trigger("jPlayer.play");
							} catch(err) {
								element.trigger("jPlayer.play"); // Fixes a problem on the iPad with multiple instances
								element.trigger("jPlayer.pause"); // Also clears delayedCommandId interval.
								self.config.delayedCommandId = window.setTimeout(function() {
									self.playHead(p);
								}, 100);
							}
						}
					},
					playHeadTime: function(e, t) {
						if(self.config.isFileSet) {
							try {
								element.trigger("jPlayer.load");
								self.config.audio.currentTime = t/1000;
								element.trigger("jPlayer.play");
							} catch(err) {
								element.trigger("jPlayer.play"); // Fixes a problem on the iPad with multiple instances
								element.trigger("jPlayer.pause"); // Also clears delayedCommandId interval.
								self.config.delayedCommandId = window.setTimeout(function() {
									self.playHeadTime(t);
								}, 100);
							}
						}
					},
					volume: function(e, v) {
						self.config.volume = v;
						self.config.audio.volume = v/100;
						self.jPlayerVolume(v);
					}
				};

				if(this.config.usingFlash) {
					$.extend(events, eventsForFlash);
				} else {
					$.extend(events, eventsForHtmlAudio);
				}

				for(var event in events) {
					var e = "jPlayer." + event;
					this.element.unbind(e);
					this.element.bind(e, events[event]);
				}

				if(this.config.usingFlash) {
					if(this._checkForFlash(8)) {
						if($.browser.msie) {
							var html_obj = '<object id="' + this.config.fid + '"';
							html_obj += ' classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"';
							html_obj += ' codebase="' + document.URL.substring(0,document.URL.indexOf(':')) + '://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab"'; // Fixed IE non secured element warning.
							html_obj += ' type="application/x-shockwave-flash"';
							html_obj += ' width="' + this.config.width + '" height="' + this.config.height + '">';
							html_obj += '</object>';

							var obj_param = new Array();
							obj_param[0] = '<param name="movie" value="' + this.config.swf + '" />';
							obj_param[1] = '<param name="quality" value="high" />';
							obj_param[2] = '<param name="FlashVars" value="id=' + escape(this.config.id) + '&fid=' + escape(this.config.fid) + '&vol=' + this.config.volume + '" />';
							obj_param[3] = '<param name="allowScriptAccess" value="always" />';
							obj_param[4] = '<param name="bgcolor" value="' + this.config.bgcolor + '" />';

							var ie_dom = document.createElement(html_obj);
							for(var i=0; i < obj_param.length; i++) {
								ie_dom.appendChild(document.createElement(obj_param[i]));
							}
							this.element.html(ie_dom);
						} else {
							var html_embed = '<embed name="' + this.config.fid + '" id="' + this.config.fid + '" src="' + this.config.swf + '"';
							html_embed += ' width="' + this.config.width + '" height="' + this.config.height + '" bgcolor="' + this.config.bgcolor + '"';
							html_embed += ' quality="high" FlashVars="id=' + escape(this.config.id) + '&fid=' + escape(this.config.fid) + '&vol=' + this.config.volume + '"';
							html_embed += ' allowScriptAccess="always"';
							html_embed += ' type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />';
							this.element.html(html_embed);
						}

					} else {
						this.element.html("<p>Flash 8 or above is not installed. <a href='http://get.adobe.com/flashplayer'>Get Flash!</a></p>");
					}
				} else {
					this.config.audio.autobuffer = this.config.autobuffer;
					this.config.audio.preload = this.config.preload;
					this.config.audio.addEventListener("canplay", function() {
						var rnd = 0.1 * Math.random(); // Fix for Chrome 4: Fix volume being set multiple times before playing bug.
						var fix = (self.config.volume < 50) ? rnd : -rnd; // Fix for Chrome 4: Solves volume change before play bug. (When new vol == old vol Chrome 4 does nothing!)
						self.config.audio.volume = (self.config.volume + fix)/100; // Fix for Chrome 4: Event solves initial volume not being set correctly.
					}, false);
					this.config.audio.addEventListener("ended", function() {
						clearInterval(self.config.jPlayerControllerId);
						self.jPlayerOnSoundComplete();
					}, false);
					this.element.append(this.config.audio);
				}

				this.element.css({'position':this.config.position, 'top':this.config.top, 'left':this.config.left});

				if(this.config.graphicsFix) {
					var html_hidden = '<div id="' + this.config.hid + '"></div>';
					this.element.append(html_hidden);

					$.extend(this.config, {
						hSel: $("#"+this.config.hid)
					});
					this.config.hSel.css({'text-indent':'-9999px'});
				}

				if(!this.config.customCssIds) {
					$.each($.jPlayer._cssId, function(name, id) {
						self.cssId(name, id);
					});
				}

				if(!this.config.usingFlash) { // Emulate initial flash call after 100ms
					this.element.css({'left':'-9999px'}); // Mobile Safari always shows the <audio> controls, so hide them.
					window.setTimeout( function() {
						self.volume(self.config.volume);
						self.jPlayerReady();
					}, 100);
				}
			},
			jPlayerReady: function(swfVersion) { // Called from Flash / HTML5 interval
				if(this.config.usingFlash) {
					this.config.swfVersion = swfVersion;
					if(this.config.swfVersionRequired != this.config.swfVersion) {
						this._error("jPlayer's JavaScript / SWF version mismatch!\n\nJavaScript requires SWF : " + this.config.swfVersionRequired + "\nThe Jplayer.swf used is : " + this.config.swfVersion);
					}
				} else {
					this.config.swfVersion = "n/a";
				}
				this.jPlayerReadyCustom();
			},
			jPlayerReadyCustom: function() {
				// Replaced by ready function from options in _init()
			},
			setFile: function(mp3, ogg) {
				this.element.trigger("jPlayer.setFile", [mp3, ogg]);
			},
			clearFile: function() {
				this.element.trigger("jPlayer.clearFile");
			},
			load: function() {
				this.element.trigger("jPlayer.load");
			},
			play: function() {
				this.element.trigger("jPlayer.play");
			},
			pause: function() {
				this.element.trigger("jPlayer.pause");
			},
			stop: function() {
				this.element.trigger("jPlayer.stop");
			},
			playHead: function(p) {
				this.element.trigger("jPlayer.playHead", [p]);
			},
			playHeadTime: function(t) {
				this.element.trigger("jPlayer.playHeadTime", [t]);
			},
			volume: function(v) {
				v = this._limitValue(v, 0, 100);
				this.element.trigger("jPlayer.volume", [v]);
			},
			cssId: function(fn, id) {
				var self = this;
				if(typeof id == 'string') {
					if($.jPlayer._cssId[fn]) {
						if(this.config.cssId[fn] != undefined) {
							this.config.cssSelector[fn].unbind("click", this.config.clickHandler[fn]);
						}
						this.config.cssId[fn] = id;
						this.config.cssSelector[fn] = $("#"+id);
						this.config.clickHandler[fn] = function(e) {
							self[fn](e);
							$(this).blur();
							return false;
						}
						this.config.cssSelector[fn].click(this.config.clickHandler[fn]);
						var display = this.config.cssSelector[fn].css("display");
						if(fn == "play") {
							this.config.cssDisplay["pause"] = display;
						}
						if(!(fn == "pause" && display == "none")) {
							this.config.cssDisplay[fn] = display;
							if(fn == "pause") {
								this.config.cssSelector[fn].css("display", "none");
							}
						}
					} else {
						this._warning("Unknown/Illegal function in cssId\n\njPlayer('cssId', '"+fn+"', '"+id+"')");
					}
				} else {
					this._warning("cssId CSS Id must be a string\n\njPlayer('cssId', '"+fn+"', "+id+")");
				}
			},
			loadBar: function(e) { // Handles clicks on the loadBar
				if( this.config.cssId.loadBar != undefined ) {
					var offset = this.config.cssSelector.loadBar.offset();
					var x = e.pageX - offset.left;
					var w = this.config.cssSelector.loadBar.width();
					var p = 100*x/w;
					this.playHead(p);
				}
			},
			playBar: function(e) { // Handles clicks on the playBar
				this.loadBar(e);
			},
			onProgressChange: function(fn) {
				if($.isFunction(fn)) {
					this.onProgressChangeCustom = fn;
				} else {
					this._warning("onProgressChange parameter is not a function.");
				}
			},
			onProgressChangeCustom: function() {
				// Replaced in onProgressChange()
			},
			jPlayerOnProgressChange: function(lp, ppr, ppa, pt, tt) { // Called from Flash / HTML5 interval
				this.config.diag.loadPercent = lp;
				this.config.diag.playedPercentRelative = ppr;
				this.config.diag.playedPercentAbsolute = ppa;
				this.config.diag.playedTime = pt;
				this.config.diag.totalTime = tt;

				if (this.config.cssId.loadBar != undefined) {
					this.config.cssSelector.loadBar.width(lp+"%");
				}
				if (this.config.cssId.playBar != undefined ) {
					this.config.cssSelector.playBar.width(ppr+"%");
				}

				this.onProgressChangeCustom(lp, ppr, ppa, pt, tt);
				this._forceUpdate();
			},
			jPlayerController: function(override) { // The HTML5 interval function.
				var pt = 0, tt = 0, ppa = 0, lp = 0, ppr = 0;
				if(this.config.audio.readyState >= 1) {
					pt = this.config.audio.currentTime * 1000; // milliSeconds
					tt = this.config.audio.duration * 1000; // milliSeconds
					tt = isNaN(tt) ? 0 : tt; // Clean up duration in Firefox 3.5+
					ppa = (tt > 0) ? 100 * pt / tt : 0;
					if((typeof this.config.audio.buffered == "object") && (this.config.audio.buffered.length > 0)) {
						lp = 100 * this.config.audio.buffered.end(this.config.audio.buffered.length-1) / this.config.audio.duration;
						ppr = 100 * this.config.audio.currentTime / this.config.audio.buffered.end(this.config.audio.buffered.length-1);
					} else {
						lp = 100;
						ppr = ppa;
					}
				}

				if(!this.config.diag.isPlaying && lp >= 100) {
					clearInterval(this.config.jPlayerControllerId);
				}

				if(override) {
					this.jPlayerOnProgressChange(lp, 0, 0, 0, tt);
				} else {
					this.jPlayerOnProgressChange(lp, ppr, ppa, pt, tt);
				}
			},
			volumeMin: function() {
				this.volume(0);
			},
			volumeMax: function() {
				this.volume(100);
			},
			volumeBar: function(e) { // Handles clicks on the volumeBar
				if( this.config.cssId.volumeBar != undefined ) {
					var offset = this.config.cssSelector.volumeBar.offset();
					var x = e.pageX - offset.left;
					var w = this.config.cssSelector.volumeBar.width();
					var p = 100*x/w;
					this.volume(p);
				}
			},
			volumeBarValue: function(e) { // Handles clicks on the volumeBarValue
				this.volumeBar(e);
			},
			jPlayerVolume: function(v) { // Called from Flash / HTML5 event
				if( this.config.cssId.volumeBarValue != null ) {
					this.config.cssSelector.volumeBarValue.width(v+"%");
					this._forceUpdate();
				}
			},
			onSoundComplete: function(fn) {
				if($.isFunction(fn)) {
					this.onSoundCompleteCustom = fn;
				} else {
					this._warning("onSoundComplete parameter is not a function.");
				}
			},
			onSoundCompleteCustom: function() {
				// Replaced in onSoundComplete()
			},
			jPlayerOnSoundComplete: function() { // Called from Flash / HTML5 interval
				this.element.trigger("jPlayer.setButtons", false);
				this.onSoundCompleteCustom();
			},
			getData: function(name) {
				var n = name.split(".");
				var p = this.config;
				for(var i = 0; i < n.length; i++) {
					if(p[n[i]] != undefined) {
						p = p[n[i]];
					} else {
						this._warning("Undefined data requested.\n\njPlayer('getData', '" + name + "')");
						return undefined;
					}
				}
				return p;
			},
			_getMovie: function() {
				return document[this.config.fid];
			},
			_checkForFlash: function (version){
				// Function checkForFlash adapted from FlashReplace by Robert Nyman
				// http://code.google.com/p/flashreplace/
				var flashIsInstalled = false;
				var flash;
				if(window.ActiveXObject){
					try{
						flash = new ActiveXObject(("ShockwaveFlash.ShockwaveFlash." + version));
						flashIsInstalled = true;
					}
					catch(e){
						// Throws an error if the version isn't available
					}
				}
				else if(navigator.plugins && navigator.mimeTypes.length > 0){
					flash = navigator.plugins["Shockwave Flash"];
					if(flash){
						var flashVersion = navigator.plugins["Shockwave Flash"].description.replace(/.*\s(\d+\.\d+).*/, "$1");
						if(flashVersion >= version){
							flashIsInstalled = true;
						}
					}
				}
				return flashIsInstalled;
			},
			_forceUpdate: function() { // For Safari and Chrome
				if(this.config.graphicsFix) {
					this.config.hSel.text(""+Math.random());
				}
			},
			_limitValue: function(value, min, max) {
				return (value < min) ? min : ((value > max) ? max : value);
			},
			_flashError: function(e) {
				this._error("Problem with Flash component.\n\nCheck the swfPath points at the Jplayer.swf path.\n\nswfPath = " + this.config.swfPath + "\nurl: " + this.config.swf + "\n\nError: " + e.message);
			},
			_error: function(msg) {
				if(this.config.errorAlerts) {
					this._alert("Error!\n\n" + msg);
				}
			},
			_warning: function(msg) {
				if(this.config.warningAlerts) {
					this._alert("Warning!\n\n" + msg);
				}
			},
			_alert: function(msg) {
				alert("jPlayer " + this.config.version + " : id='" + this.config.id +"' : " + msg);
			}
		};
	})(jQuery);



/* 2.4 BOOTSTRAP TOOLTIP ---------------------------------------------------------------------- */
/* ===========================================================
 * bootstrap-tooltip.js v2.0.0
 * http://twitter.github.com/bootstrap/javascript.html#tooltips
 * Inspired by the original jQuery.tipsy by Jason Frame
 * ===========================================================
 * Copyright 2012 Twitter, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================== */

!function( $ ) {

  "use strict"

 /* TOOLTIP PUBLIC CLASS DEFINITION
  * =============================== */

  var Tooltip = function ( element, options ) {
    this.init('tooltip', element, options)
  }

  Tooltip.prototype = {

    constructor: Tooltip

  , init: function ( type, element, options ) {
      var eventIn
        , eventOut

      this.type = type
      this.$element = $(element)
      this.options = this.getOptions(options)
      this.enabled = true

      if (this.options.trigger != 'manual') {
        eventIn  = this.options.trigger == 'hover' ? 'mouseenter' : 'focus'
        eventOut = this.options.trigger == 'hover' ? 'mouseleave' : 'blur'
        this.$element.on(eventIn, this.options.selector, $.proxy(this.enter, this))
        this.$element.on(eventOut, this.options.selector, $.proxy(this.leave, this))
      }

      this.options.selector ?
        (this._options = $.extend({}, this.options, { trigger: 'manual', selector: '' })) :
        this.fixTitle()
    }

  , getOptions: function ( options ) {
      options = $.extend({}, $.fn[this.type].defaults, options, this.$element.data())

      if (options.delay && typeof options.delay == 'number') {
        options.delay = {
          show: options.delay
        , hide: options.delay
        }
      }

      return options
    }

  , enter: function ( e ) {
      var self = $(e.currentTarget)[this.type](this._options).data(this.type)

      if (!self.options.delay || !self.options.delay.show) {
        self.show()
      } else {
        self.hoverState = 'in'
        setTimeout(function() {
          if (self.hoverState == 'in') {
            self.show()
          }
        }, self.options.delay.show)
      }
    }

  , leave: function ( e ) {
      var self = $(e.currentTarget)[this.type](this._options).data(this.type)

      if (!self.options.delay || !self.options.delay.hide) {
        self.hide()
      } else {
        self.hoverState = 'out'
        setTimeout(function() {
          if (self.hoverState == 'out') {
            self.hide()
          }
        }, self.options.delay.hide)
      }
    }

  , show: function () {
      var $tip
        , inside
        , pos
        , actualWidth
        , actualHeight
        , placement
        , tp

      if (this.hasContent() && this.enabled) {
        $tip = this.tip()
        this.setContent()

        if (this.options.animation) {
          $tip.addClass('fade')
        }

        placement = typeof this.options.placement == 'function' ?
          this.options.placement.call(this, $tip[0], this.$element[0]) :
          this.options.placement

        inside = /in/.test(placement)

        $tip
          .remove()
          .css({ top: 0, left: 0, display: 'block' })
          .appendTo(inside ? this.$element : document.body)

        pos = this.getPosition(inside)

        actualWidth = $tip[0].offsetWidth
        actualHeight = $tip[0].offsetHeight

        switch (inside ? placement.split(' ')[1] : placement) {
          case 'bottom':
            tp = {top: pos.top + pos.height, left: pos.left + pos.width / 2 - actualWidth / 2}
            break
          case 'top':
            tp = {top: pos.top - actualHeight, left: pos.left + pos.width / 2 - actualWidth / 2}
            break
          case 'left':
            tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left - actualWidth}
            break
          case 'right':
            tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left + pos.width}
            break
        }

        $tip
          .css(tp)
          .addClass(placement)
          .addClass('in')
      }
    }

  , setContent: function () {
      var $tip = this.tip()
      $tip.find('.tooltip-inner').html(this.getTitle())
      $tip.removeClass('fade in top bottom left right')
    }

  , hide: function () {
      var that = this
        , $tip = this.tip()

      $tip.removeClass('in')

      function removeWithAnimation() {
        var timeout = setTimeout(function () {
          $tip.off($.support.transition.end).remove()
        }, 500)

        $tip.one($.support.transition.end, function () {
          clearTimeout(timeout)
          $tip.remove()
        })
      }

      $.support.transition && this.$tip.hasClass('fade') ?
        removeWithAnimation() :
        $tip.remove()
    }

  , fixTitle: function () {
      var $e = this.$element
      if ($e.attr('title') || typeof($e.attr('data-original-title')) != 'string') {
        $e.attr('data-original-title', $e.attr('title') || '').removeAttr('title')
      }
    }

  , hasContent: function () {
      return this.getTitle()
    }

  , getPosition: function (inside) {
      return $.extend({}, (inside ? {top: 0, left: 0} : this.$element.offset()), {
        width: this.$element[0].offsetWidth
      , height: this.$element[0].offsetHeight
      })
    }

  , getTitle: function () {
      var title
        , $e = this.$element
        , o = this.options

      title = $e.attr('data-original-title')
        || (typeof o.title == 'function' ? o.title.call($e[0]) :  o.title)

      title = title.toString().replace(/(^\s*|\s*$)/, "")

      return title
    }

  , tip: function () {
      return this.$tip = this.$tip || $(this.options.template)
    }

  , validate: function () {
      if (!this.$element[0].parentNode) {
        this.hide()
        this.$element = null
        this.options = null
      }
    }

  , enable: function () {
      this.enabled = true
    }

  , disable: function () {
      this.enabled = false
    }

  , toggleEnabled: function () {
      this.enabled = !this.enabled
    }

  , toggle: function () {
      this[this.tip().hasClass('in') ? 'hide' : 'show']()
    }

  }


 /* TOOLTIP PLUGIN DEFINITION
  * ========================= */

  $.fn.tooltip = function ( option ) {
    return this.each(function () {
      var $this = $(this)
        , data = $this.data('tooltip')
        , options = typeof option == 'object' && option
      if (!data) $this.data('tooltip', (data = new Tooltip(this, options)))
      if (typeof option == 'string') data[option]()
    })
  }

  $.fn.tooltip.Constructor = Tooltip

  $.fn.tooltip.defaults = {
    animation: true
  , delay: 0
  , selector: false
  , placement: 'top'
  , trigger: 'hover'
  , title: ''
  , template: '<div class="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
  }

}( window.jQuery )

/*

	CONTENTS ----------

	1.SEARCH
		1.1 POPLATE SEARCH BOX
		1.2 EMPTY SEARCH STRING
	2.MENU
		2.1 BUILD MENU
		2.2 MENU DISPLAY
		2.3 MENU OMNITURE TRIGGER
	3.POPUPS & MODALS
		3.1 POPUPS & TOOLTIPS
		3.2 MODALS
		3.3 IMAGE MODALS
	4.PAGE/SECTION SPECIFIC
		4.1 SHIPPING ADDRESS
		4.2 ORDER REVIEW
		4.3 PRODUCT DETAIL
		4.4 ARTICLE
		4.5 ORDER HISTORY
		4.6 QUICK ITEM ADD
		4.7 PRODUCT LIST-GRID
	5.VIDEO
	6.FORMS
		6.1 STATUS MESSAGES
		6.2 SURVEY
		6.3 PLACEHOLDER
		6.4 URL SELECTORS
	7.WIDGETS
		7.1 MEDIA
		7.2 SLIDER
		7.3 SLIDESHOW
		7.4 ROTATOR
		7.5 ADD TO CART - AJAX
		7.6 VARIANT SELECTOR TOGGLE
	8.NAVIGATION
		8.1 REFINEMENT MENU
		8.2 MATCHING CATEGORIES
		8.3 TABS OMNITURE TRIGGER
		8.4 LIFEWAY NETWORK
	9.GET URL VARIABLES

	-------------------

*/



/* jQuery.noConflict(); */
jQuery(document).ready(function() {

	/* 1.SEARCH
	---------------------------------------------------------------------- */

	/* 1.1 POPLATE SEARCH BOX ---------------------------------------------------------------------- */
	// production script only



	/* 1.2 EMPTY SEARCH STRING ---------------------------------------------------------------------- */
	// production script only



	/* 2.MENU
	---------------------------------------------------------------------- */

		/* 2.1 BUILD MENU ---------------------------------------------------------------------- */
		// production script only



		/* 2.2 MENU DISPLAY ---------------------------------------------------------------------- */

		jQuery('#primary_nav').lwMenu();



		/* 2.3 MENU OMNITURE TRIGGER ---------------------------------------------------------------------- */
		// production script only



	/* 3.POPUPS & MODALS
	---------------------------------------------------------------------- */

		/* 3.1 POPUPS & TOOLTIPS ---------------------------------------------------------------------- */

		// Popups
		// Build popup boxes
		jQuery('.popup').one('click', function(e) {
			e.preventDefault();

			var link = jQuery(this).attr("href");
			jQuery(this).after('<div class="popup_message"></div>');
			// Look to see if the link is to a box in this page or not
			if (link.match(/^#/i)) {
				var message = jQuery(link).html();
				jQuery(this).next('.popup_message').html(message).append('<p class="close"><a href="#">Close</a></p>').bgiframe();
			} else {
				var message = jQuery(this).attr('rel');
				// See if a target box ID is specified in the rel attribute of the link, and only load that box if it is
				if (message) {
					jQuery(this).next('.popup_message').load(link+' #'+message, function() {
						jQuery(this).append('<p class="close"><a href="#">Close</a></p>');
					}).bgiframe();
				} else {
					jQuery(this).next('.popup_message').load(link, function() {
						jQuery(this).append('<p class="close"><a href="#">Close</a></p>');
					}).bgiframe();
				}
			}
		});

		// Build popup boxes for help messages
		jQuery('.form_input p.help').each(function(index) {
			jQuery(this).before('<a href="#" class="popup help_indicator">?</a>').addClass('popup_message').append('<span class="close"><a href="#">Close</a></span>').bgiframe();
			var visibility = jQuery(this).parents('form .view_toggle').css('display');
			// if the element is hidden, the dimensions will not be calculated properly, so we need to show them first
			if (visibility == 'none') {
				jQuery(this).parents('form .view_toggle').show();
			}
			var position = jQuery(this).parent().find('input, select, textarea').position();
			var label_width = jQuery(this).parent().find('label').outerWidth(true);
			var input_width = jQuery(this).parent().find('input, select, textarea').outerWidth();
			// if the element was hidden, let's hide it again so things are back to normal
			if (visibility == 'none') {
				jQuery(this).parents('form .view_toggle').hide();
			}
			if (position.left == 0) {
				var left = label_width + input_width + 12;
			} else {
				var left = position.left + input_width + 12;
			}
			jQuery(this).prev().css({
				left: left
			});
		});

		// Popup functionality
		jQuery('.popup').click(popupPlacer).parent().addClass('popup_container');

		function popupPlacer(e) {
			e.preventDefault();

			var offset = jQuery(this).parent().offset();
			var height = jQuery(this).next('.popup_message').outerHeight();
			var width = jQuery(this).next('.popup_message').outerWidth();
			var pageWidth = jQuery(document).width();
			var scrollHeight = e.pageY - jQuery(document).scrollTop();
			var headerHeight = jQuery('#header').outerHeight() - jQuery(document).scrollTop();
			if (headerHeight < 0) {
				headerHeight = 0;
			}
			var left, top;

			// make sure the popup will not go beyond the left or right edges of the page, and center it above the click location if not
			if ((e.pageX + (width/2) + 15) > pageWidth) {
				left = pageWidth - width - offset.left - 15;
			} else if ((e.pageX - (width/2) - 15) < 0) {
				left = 0;
			} else {
				left = e.pageX - offset.left - (width/2);
			}

			// the popup should show up above the click location unless there isn't enough room in the window
			if (scrollHeight - headerHeight - height - 20 < 0) {
				top = e.pageY - offset.top + 20;
			} else {
				top = e.pageY - offset.top - height - 20;
			}

			jQuery(this).next('.popup_message').css({
				left: left,
				top: top
			}).toggle();
		}

		jQuery(".popup_message .close a").live('click', function(e) {
			e.preventDefault();
			jQuery(this).parent().parent().toggle();
		});


		// tooltips
		jQuery('[rel="tooltip"]').tooltip({
			animation: true
		})
		// disable click functionality as needed
		.filter('.disabled').click(function(e) {
			e.preventDefault();
		});


		/* 3.2 MODALS ---------------------------------------------------------------------- */

		jQuery('body').delegate('.modal', 'click', function(e) {
			if (!jQuery(this).data('modal-init')) {
				e.preventDefault();
				jQuery(this).data('modal-init', true).lwModal();
			}
	    });
	    jQuery('body').delegate('.modal-large', 'click', function(e) {
			if (!jQuery(this).data('modal-init')) {
				e.preventDefault();
				jQuery(this).data('modal-init', true).lwModal({
					'extraClass' : 'large'
				});
			}
	    });



		/* 3.3 IMAGE MODALS ---------------------------------------------------------------------- */
		// In PRODUCTION, this script creates a modal every time the link is clicked, instead of just the first time. It kills the modal completely when the modal is closed.

		jQuery('.product_images .primary a').one('click', function() {
			var link = jQuery(this).attr('href');
			jQuery('body').append('<div class="image_modal" style="display:none;"><img src="'+link+'" alt=""><p class="close"><a href="#">Close</a></p><p class="close close_button"><a href="#">Close</a></p></div>');
			return false;
		}).click(function() {
			var $image_modal = jQuery('.image_modal');
			var $image = $image_modal.children("img");

			var scrollHeight = jQuery(document).scrollTop();
			var pageWidth = jQuery(window).width();
			var pageHeight = jQuery(window).height();
			if ($image[0].complete) {
				$image.css({height: "auto", width: "auto"});
				$image_modal.toggle();
				var modalWidth = $image_modal.outerWidth();
				var modalHeight =  $image_modal.outerHeight();
				var widthDiff = pageWidth - modalWidth - 144;
				var heightDiff = pageHeight - modalHeight - 144;
				if (widthDiff < 0 && widthDiff < heightDiff) {
					$image.width(pageWidth - 144).css({height: "auto"});
				} else if (heightDiff < 0 && heightDiff < widthDiff) {
					$image.height(pageHeight - 144).css({width: "auto"});
				}
				var height = $image_modal.outerHeight();
				var width = $image_modal.outerWidth();
				$image_modal.toggle();
				var top = (pageHeight/2) - (height/2) + scrollHeight;
				var left = (pageWidth/2) - (width/2);
				$image_modal.css({
					top: top,
					left: left
				}).toggle().bgiframe();
			} else {
				$image.load(function(){
					$image.css({height: "auto", width: "auto"});
					$image_modal.toggle();
					var modalWidth = $image_modal.outerWidth();
					var modalHeight =  $image_modal.outerHeight();
					var widthDiff = pageWidth - modalWidth - 144;
					var heightDiff = pageHeight - modalHeight - 144;
					if (widthDiff < 0 && widthDiff < heightDiff) {
						$image.width(pageWidth - 144).css({height: "auto"});
					} else if (heightDiff < 0 && heightDiff < widthDiff) {
						$image.height(pageHeight - 144).css({width: "auto"});
					}
					var height = $image_modal.outerHeight();
					var width = $image_modal.outerWidth();
					$image_modal.toggle();
					var top = (pageHeight/2) - (height/2) + scrollHeight;
					var left = (pageWidth/2) - (width/2);
					$image_modal.css({
						top: top,
						left: left
					}).toggle().bgiframe();
				});
			}
			return false;
		});

		jQuery(".image_modal").live('click', function() {
			jQuery(this).toggle();
		});
		jQuery(".image_modal .close a").live('click', function() {
			jQuery(this).closest(".image_modal").toggle();
			return false;
		});




		/* 4.PAGE/SECTION SPECIFIC
		---------------------------------------------------------------------- */

			/* 4.1 SHIPPING ADDRESS ---------------------------------------------------------------------- */

			// Create Saved Addresses Toggle
			jQuery("form.shipping_address .saved_addresses").before('<p class="view_toggler"><a href="#">'+jQuery(this).find('h3').text()+'</a></p>').addClass("view_toggle");



			/* 4.2 ORDER REVIEW ---------------------------------------------------------------------- */

			jQuery(".billing_details .email form div:first").before('<p class="edit view_toggler"><a href="#">Add an E-mail Address</a></p>').addClass("view_toggle");



			/* 4.3 PRODUCT DETAIL ---------------------------------------------------------------------- */

			// Product Review
			jQuery("#review_rating").after('<p class="set_rating"><a href="star1" class="one">1 star</a> <a href="star2" class="two">2 stars</a> <a href="star3" class="three">3 stars</a> <a href="star4" class="four">4 stars</a> <a href="star5" class="five">5 stars</a></p>');
			jQuery("p.set_rating").hover(function() {
				jQuery(this).addClass("active");
			}, function() {
				jQuery(this).removeClass("active");
			}).find("a").click(function() {
				var rating = jQuery(this).attr('href');
				jQuery(this).closest("p").find("a").removeClass("active");
				jQuery(this).addClass("active");
				jQuery(this).closest("p").prev().find("option."+rating).attr("selected", "selected");
				return false;
			});

			jQuery("form.review input[maxlength], form.review textarea[maxlength]").each(function() {
				var characters = jQuery(this).attr('maxlength');
				jQuery(this).after('<p class="characters"><span>'+characters+'</span> characters remaining.</p>');
			}).focus(function() {
				var characters = jQuery(this).attr('maxlength');
				var field = jQuery(this);
				var charContainer = jQuery(this).next().find('span');
				// start the timer
				charactersTimer = setInterval(function() {
					var remaining = characters - field.attr('value').length;
					var value = field.attr('value').substring(0, characters);
					if (remaining == 0) {
						charContainer.parent().addClass('full');
						charContainer.text(remaining);
					} else if (remaining < 0) {
						field.attr('value', value)
						charContainer.text('0').parent().addClass('full');
					} else {
						charContainer.text(remaining).parent().removeClass('full');
					}
				}, 10);
			}).blur(function() {
				clearInterval(charactersTimer);
			});

			// Community Guidelines
			jQuery(document).ready(function() {
				jQuery('.community-guidelines').css("display","block");
		  		jQuery('.hidden-area').hide();
		  		jQuery('.showhide-button').toggle(function() {
		  		  jQuery(this).parent().next().slideDown('fast').removeClass('hidden-area').preventDefault;
		  		    jQuery(this).html('Hide Community Guidelines');
		  		  },function() {
		  		    jQuery(this).parent().next().slideUp('fast').addClass('hidden-area').preventDefault;
		  		    jQuery(this).html('Show Community Guidelines');
		  		});
		  	});

			// Editorial Reviews
			jQuery(document).ready(function() {
		    	var show;
		    	jQuery('.more_reviews_content').hide();
		    	jQuery('.show_more_reviews a').click(function(event) {
		      		if (show)
		      			{ showhide(jQuery(this),'Show More Editorial Reviews',false); }
		      		else
		      			{ showhide(jQuery(this),'Hide Additional Editorial Reviews',true); }
		      		return false;
			      	function showhide(reviews,switchtext,switchstate) {
			        	reviews.parents('.show_more_reviews').prev('.more_reviews_content').toggle('fast');
			        	reviews.text(switchtext);
			        	show = switchstate;
			      	}
		    	});
			});

			// Fix IE8 select width on PDP variants
			var selecterWidth = jQuery('.ie8 .selector-wrap').outerWidth();
			jQuery('.ie8 .selector-wrap').css('min-width',selecterWidth+'px');
			jQuery('.ie8 .selector-wrap select').on('mouseover', function(){

				$this = jQuery(this);
					// on mousover add class with styles to expand the select
			  	$this.closest('.selector-wrap').addClass('stretch-it');
					// on mousout remove class with styles to contract the select
			  	$this.bind('mouseout', function(){
			      $this.closest('.selector-wrap').removeClass('stretch-it');
			    });
			}).bind('blur change', function(){
					// when leaving the select remove class to contract the select
			  $this.closest('.selector-wrap').removeClass('stretch-it');
			}).on('click', function(){
					// if clicked unbind the mouseout event so that hovering the options still works
				$this.unbind('mouseout');
			});


			// Product Description Toggle
			//-----------------------------------
			// this function is for detecting transition event capabilities in the browser with jQuery - use $.support.transition in your if statements
			// this function is for detecting transition event capabilities in the browser with jQuery - use $.support.transition in your if statements
			jQuery.support.transition = (function(){
			    var thisBody = document.body || document.documentElement,
			        thisStyle = thisBody.style,
			        support = thisStyle.transition !== undefined || thisStyle.WebkitTransition !== undefined || thisStyle.MozTransition !== undefined || thisStyle.MsTransition !== undefined || thisStyle.OTransition !== undefined;
			    return support;
			})();

			// setup initial variables
			var $copyWrapper = jQuery("#productLongDescription");

			$copyWrapper.each(function() {
			  // get height - have to set the variable here because Safari dies when getting height after a max-height is applied by a new class
			  var initCopyHeight = jQuery(this).height();

			  // add a class to know we're doing stuff here
			  jQuery(this).addClass('initialized');

			  // get copyHeight by cloning our element, grabbing the value, then removing it
			  // this stupidify is because Safari barfs when a max-height is added via a class
			  var $clone = jQuery(this).clone().hide().appendTo('body');
			  var copyHeight = parseFloat($clone.css('max-height'));
			  $clone.remove();

			  var $copyInner;

			  // check to see if the text is long enough to even worry with this mess
			  if (initCopyHeight < copyHeight) {
			    jQuery(this).css({ 'max-height': 'none' }); // if so, clear the max-height so their aren't any problems resizing
			  } else {
			  	// add toggle link
				jQuery('<span class="more-less">Show more</span>').insertAfter('#productLongDescription');
				// add a class to know we're doing stuff here
				var $moreLess = jQuery('.more-less');

			    // add the inner div
			    jQuery(this).wrapInner('<div class="copy__inner"></div>');
			    $copyInner = jQuery(this).find('.copy__inner');

			    // add the gradient overlay
			    jQuery(this).append('<div class="copy__gradient"></div>');

			    // add click functionality
			    $moreLess.click(function(){
			      // setup variables
			      var maxHeight;

			      // if css transitions are supported, we'll use those
			      if (jQuery.support.transition) {
			        maxHeight = { 'max-height': $copyInner.outerHeight(true) };
			      } else { // if not, we'll override max-height so everything shows
			        maxHeight = { 'max-height': 'none' };
			      }

			      // if the element has the 'reveal' class, we're setting it back to stock
			      if ($copyWrapper.hasClass('reveal')) {
			        $copyWrapper.css(maxHeight); // set the max-height to the height of the contents
			        $copyWrapper.css('max-height'); // force the stupid browser to repaint
			        $copyWrapper.css({ 'max-height': copyHeight, 'transition': '' }); // set the heights back to the default value
			      } else {
			        $copyWrapper.css(maxHeight);
			        $copyWrapper.on('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd', function(e){
			          if(e.target === e.currentTarget) { // to keep multiple events from being fired (because of children elements with transitions)
			            $copyWrapper.css({ 'max-height': 'none', 'transition': 'none' }); // set the max-height to none after the transition so page-resizing works
			            $copyWrapper.off('transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd'); // unbind the transition event so it doesn't fire when we collapse the div again
			          }
			        });
			      }

			      $copyWrapper.toggleClass("reveal");
			      if($moreLess.text()==="Show less"){
			        $moreLess.text('Show more');
			      } else {$moreLess.text('Show less');}
			    });
			  }
			});

			/* 4.4 ARTICLE ---------------------------------------------------------------------- */

			// Related Audio Content on Article Pages
			var audioPlayer = 0;
			jQuery(".article .related .audio:gt(0) .audio_player, .article-detail .related .audio:gt(0) .audio_player").hide();
		    jQuery(".article .related .audio a[href$='mp3'], .article-detail .related .audio a[href$='mp3']").each(function() {
		        var audioFile =  jQuery(this).attr('href');
		        var player = jQuery(this).closest("li").find('.audio_player');
		        var jpPlayTime = jQuery(this).closest("li").find(".jp-play-time");
				var jpTotalTime = jQuery(this).closest("li").find(".jp-total-time");

		        jQuery(this).closest("li").find(".jplayer").jPlayer({
		            ready: function () {
		                this.element.jPlayer("setFile", audioFile);
		            },
		            swfPath: "swf/",
		            width: "0",
		            height: "0",
		            preload: "none",
		            volume: 100
		        })
		        .jPlayer( "cssId", "play", "jplayer_play"+audioPlayer )
		        .jPlayer( "cssId", "pause", "jplayer_pause"+audioPlayer )
		        .jPlayer( "cssId", "stop", "jplayer_stop"+audioPlayer )
		        .jPlayer( "cssId", "playlist", "jplayer_playlist"+audioPlayer )
		        .jPlayer( "cssId", "volumeMin", "jplayer_volume_min"+audioPlayer )
		        .jPlayer( "cssId", "volumeMax", "jplayer_volume_max"+audioPlayer )
		        .jPlayer( "cssId", "volumeBar", "jplayer_volume_bar"+audioPlayer )
		        .jPlayer( "cssId", "volumeBarValue", "jplayer_volume_bar_value"+audioPlayer )
		        .jPlayer( "cssId", "loadBar", "jplayer_load_bar"+audioPlayer ).jPlayer( "cssId", "playBar", "jplayer_play_bar"+audioPlayer )
		        .jPlayer("onProgressChange", function(loadPercent, playedPercentRelative, playedPercentAbsolute, playedTime, totalTime) {
		            jpPlayTime.text(jQuery.jPlayer.convertTime(playedTime));
		            jpTotalTime.text(jQuery.jPlayer.convertTime(totalTime));
		        });
		        jQuery(this).click(function() {
		            jQuery(".article .related .audio .audio_player, .article-detail .related .audio .audio_player").hide().find(".jplayer").jPlayer("pause");
		            player.toggle();
		            return false;
		        });
		        audioPlayer++;
		    });



			/* 4.5 ORDER HISTORY ---------------------------------------------------------------------- */

			// filter form
			jQuery("form.filter h2").wrap('<a href="#"></a>').append(' <span>Expand</span>').parent().addClass("expand").toggle(function() {
				jQuery(this).removeClass("expand").addClass("collapse").next().slideDown().prev().find('span').text('Collapse');
				return false;
			}, function() {
				jQuery(this).removeClass("collapse").addClass("expand").next().slideUp().prev().find('span').text('Expand');
				return false;
			});

			// row clicks
			jQuery("table.orders tr:has(td)").click(function() {
				var link = jQuery(this).find("a").attr("href");
				document.location.href = link;
			});



			/* 4.6 QUICK ITEM ADD ---------------------------------------------------------------------- */

			// function to detect the url parameter
			var QueryString = function () {
			// This function is anonymous, is executed immediately and
			// the return value is assigned to QueryString!
			var query_string = {};
			var query = window.location.search.substring(1);
			var vars = query.split("&");
			for (var i=0;i<vars.length;i++) {
			  var pair = vars[i].split("=");
			      // If first entry with this name
			  if (typeof query_string[pair[0]] === "undefined") {
			    query_string[pair[0]] = pair[1];
			      // If second entry with this name
			  } else if (typeof query_string[pair[0]] === "string") {
			    var arr = [ query_string[pair[0]], pair[1] ];
			    query_string[pair[0]] = arr;
			      // If third or later entry with this name
			  } else {
			    query_string[pair[0]].push(pair[1]);
			  }
			}
			  return query_string;
			} ();


			// toggling visibility on load
			if (QueryString.quicktoggle) {
				jQuery('.quick_item')
				.find('.toggler').addClass('is-active is-init')
				.end()
				.find('.toggle-target').addClass('is-active is-init')
				.end()
				.find('.toggler-button').each(function() {
					if (jQuery(this).text() == 'Show') {
					   jQuery(this).text('Hide');
					} else if (jQuery(this).text() == 'Hide') {
					   jQuery(this).text('Show');
					}
				})
				.end()
				.find('#itemNumber').focus();
			}

			jQuery('.toggler-button').on('click', function(e) {
			  e.preventDefault();
			  var $this = jQuery(this),
			      $toggleParent = $this.closest('.toggler');
			      $toggleTarget = jQuery($this.attr('href'));
			      toggleText = $this.text();

			  $toggleParent.toggleClass('is-active').removeClass('is-init');
			  $toggleTarget.toggleClass('is-active').removeClass('is-init');

			  if (toggleText == 'Show') {
			    $this.text('Hide');
			  } else if (toggleText == 'Hide') {
			    $this.text('Show');
			  }
			});

			/* v ------------------------------------------------------------- */
		    var string_length = 55;
		    var product_grid = jQuery('.product-grid');
		    product_grid.addClass('absolute');
		    if(jQuery('.col_full .product-grid').length>0){string_length = 45;}
			product_grid.find('.product').each(function(index) {
				var temp_this = jQuery(this).find('h3 a');
				var title = temp_this.text();
				temp_this.attr('title',title);
				var title_length = title.length;

				if(title_length > string_length)	{
					var shortText = jQuery.trim(title.substring(0, string_length));
					temp_this.text(shortText).append('&#133;');
				}
			});


		/* 5.VIDEO
		---------------------------------------------------------------------- */
		// production script only

		// video sizing
		jQuery('.BrightcoveExperience').load(function() {
			jQuery(this).css('width', '99.99%').delay(1, "myQueue").queue("myQueue", function(){
				jQuery('iframe').css('width', '100%');
			}).dequeue("myQueue");
		});

		// video download links
		jQuery('a.video-download').each(function() {
		    var $link = jQuery(this);
		    var videoId = $link.data('video-id');
		    var videoUrl;
		    // the &callback=? bit is to make sure this works as JSONP - across domains
		    jQuery.getJSON("http://api.brightcove.com/services/library?command=find_video_by_id&video_id=" + videoId + "&token=YtF9fah-lggQ36JR_1swduspr4EmQIX6jVyribjm-HLpPAX6TuJubA..&video_id=1520880903001&video_fields=renditions&media_delivery=http&callback=?", function(jsonData) {
		        // just grab the renditions out of the json response
		        var renditions = jsonData.renditions;

		        if (renditions.length > 0) {
		            // sort the renditions so the largest video is the first one
		            renditions = renditions.sort(function(a,b) {
		                return b.size - a.size;
		            });
		            // set the url of the largest video to the variable
		            videoUrl = renditions[0].url;
		            // change our the href of the link with this url from Brightcove
		            $link.attr('href', videoUrl);
		        }
		    });
		});



		/* 6.FORMS
		---------------------------------------------------------------------- */

			/* 6.1 STATUS MESSAGES ---------------------------------------------------------------------- */
			// production script only



			/* 6.2 SURVEY ---------------------------------------------------------------------- */
			// Survey Form

			// this needs to be removed because the feedback form was removed
			jQuery("#survey_url").val(jQuery(location).attr("href"));



			/* 6.3 PLACEHOLDER ---------------------------------------------------------------------- */

			if (!Modernizr.input.placeholder) { jQuery('input[placeholder],textarea[placeholder]').lwPlaceholder(); }



			/* 6.4 URL SELECTORS ---------------------------------------------------------------------- */

			jQuery('form#selector select').lwSelectGo();



		/* 7.WIDGETS
		---------------------------------------------------------------------- */

			/* 7.1 MEDIA ---------------------------------------------------------------------- */

			jQuery(".media").lwMedia();



			/* 7.2 SLIDER ---------------------------------------------------------------------- */

			jQuery(".slider").lwSlider();



			/* 7.3 SLIDESHOW ---------------------------------------------------------------------- */

			jQuery(".slideshow").lwSlideshow();



			/* 7.4 ROTATOR ---------------------------------------------------------------------- */

			jQuery("#rotator_box").lwRotator();



			/* 7.5 ADD TO CART - AJAX ------------------------------------------------------------- */

			var $minicart = jQuery("#cart");
		    jQuery(".ajax-add").on('click.ajax-add', function(e) {
		        e.preventDefault();

		        var $this, query, itemNumber, quantity, cartRefreshMessage, postData;
		        $this = jQuery(this);
		        query = this.search.substr(1);
		        itemNumber = query.match(/itemNumber=([^&]+)/)[1];
		        quantity = query.match(/quantity=([^&]+)/)[1];
		        cartRefreshMessage = 'Refreshing';
		        postData = 'itemNumber='+itemNumber+'&quantity='+quantity;

		        jQuery.post("/webapp/wcs/stores/servlet/QuickOrderItemAdd?URL=AjaxOrderItemAddView&errorViewName=AjaxOrderItemAddView", postData, function(result) {
		            if(result.indexOf("LIFEWAY_AJAX_SUCCESS")==-1) {
		                alert("Unable to add item number: "+itemNumber+". Please Contact Lifeway support for further assistance.");
		            } else {
		            	$this.off('click.ajax-add')
		            	.text('View in Cart')
		            	.attr('href', '/OrderDisplay?langId=-1&amp;catalogId=10001&amp;storeId=10054&amp;URL=CheckoutShoppingCartView');

		                $minicart.html("<span>"+cartRefreshMessage+"</span>");
		                jQuery.ajax({
		                    url: "/webapp/wcs/stores/servlet/MiniCartDisplayAjax",
		                    cache: false,
		                    dataType: "html",
		                    success: function(data){$minicart.html(data)}
		                });
		            }
		        });
		    });


			/* 7.6 VARIANT SELECTOR TOGGLE -------------------------------------------------- */
			// collapse toggle on pageload
			// $variants = jQuery('.variants.selector-toggle');
			// var $selectToggleContent = $variants.find('.toggle-content');
			// var initSelectHeight = $selectToggleContent.height();

			// $variants.addClass('initialized');

			// jQuery('.variants.selector-toggle').find('.toggle-head').on('click', function() {
			// 	$this = jQuery(this).closest('.selector-toggle.initialized');
			// 	$this.closest('.selector-toggle.initialized').toggleClass('reveal');
			// 	if($this.closest('.selector-toggle.initialized').hasClass('reveal')){
			// 		$this.find('.toggle-content').css({'max-height':initSelectHeight});
			// 		var selectTimer = parseFloat($this.find('.toggle-content').css('transition-duration'))*1000;
			// 		setTimeout(setCssOverflow, selectTimer);
			// 	} else {
			// 		$this.find('.toggle-content').css({'max-height': '0px','overflow':'hidden'});
			// 	}

			// });
			// function setCssOverflow() {
			// 	$this.find('.toggle-content').css('overflow','visible');
			// }



		/* 8.NAVIGATION
		---------------------------------------------------------------------- */

			/* 8.1 REFINEMENT MENU ---------------------------------------------------------------------- */

			jQuery(".refinements h3").lwMenuToggle();



			/* 8.2 MATCHING CATEGORIES ---------------------------------------------------------------------- */
			// "Matching Categories" more link

			jQuery('.results_info').lwListToggle().show();



			/* 8.3 TABS OMNITURE TRIGGER ---------------------------------------------------------------------- */
			// production script only



			/* 8.4 LIFEWAY NETWORK ---------------------------------------------------------------------- */

			jQuery('<li class="more"><a href="#network_extra">More</a></li>').appendTo('#network ul:first').find('a').toggle(function() {
			  	jQuery(this).addClass('on');
				jQuery('#network_extra').addClass('show');
			}, function() {
				jQuery('#network_extra').removeClass('show');
				jQuery('#network').find('.more a').removeClass('on');
			});

		jQuery('#myTab a').click(function (e) {
		  e.preventDefault();
		  jQuery(this).tab('show');
		});

// END DOCUMENT READY
});
// YOU ARE NOW OUT OF THE DOCUMENT READY FUNCTION



/* 9.GET URL VARIABLES
---------------------------------------------------------------------- */
// production only script