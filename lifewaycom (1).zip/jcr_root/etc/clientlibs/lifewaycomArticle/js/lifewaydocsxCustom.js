$(document).ready(function(){

	$(this).foundation();

});
