use(["/libs/wcm/foundation/components/utils/AuthoringUtils.js"],function(AuthoringUtils) {
    var image = {};

	granite.resource.resolve(granite.resource.path + "/image").then(function (imageResource) {
        if(imageResource.properties["alt"]){
			image.altText = imageResource.properties["alt"];
        }
        if (imageResource.properties["fileReference"]) {
            image.path = imageResource.properties["fileReference"];
        } else {
          	log.debug("Image path not found");
        }
    }, function () {
         log.debug("Image path not found");
    });

    return image;
});