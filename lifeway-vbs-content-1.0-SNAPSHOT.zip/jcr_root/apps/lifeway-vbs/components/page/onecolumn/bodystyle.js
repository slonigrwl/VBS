/*
 * Comments go here
 */
"use strict";
use(function() {
    var pagestyle = {};
    
    pagestyle.myClass = wcm.currentPage.properties['bodyStyle'];
    log.debug( "pagestyle.myClass: " + pagestyle.myClass );   
    
    return pagestyle;
});
