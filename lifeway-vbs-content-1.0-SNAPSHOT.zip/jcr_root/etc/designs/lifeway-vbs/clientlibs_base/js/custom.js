jQuery( document ).ready(function() {
  // check to see  if there are there tabs on the page
  if(jQuery('.tabs').length>0) {
    var hash = window.location.hash;
    var $tabs = jQuery('.tabs');
    var $all_tabs_content = jQuery('.all-tabs-content');
    // activate tabs with class that hides the non-active
    $tabs.addClass('on').find('.tab-title:first-child').addClass('active');
    $all_tabs_content.addClass('on').find('.tab-content:first-child').addClass('active');
    // create mobile tab selector dropdown
    var tab_select_code_str = '<select class="tabs-select">';
    $tabs.find('.tab-title').each(function(){
      tab_select_code_str += '<option value="'+jQuery(this).find('a').attr('href')+'">'+jQuery(this).find('a').text()+'</option>';
    });
    tab_select_code_str += '</select>';
    jQuery('.tab-wrapper').prepend(tab_select_code_str);
    var $tabs_select = jQuery('.tabs-select');
    // click event to switchout content
    $tabs.find('.tab-title a').on('click', function(e){
      e.preventDefault();
      switchout(jQuery(this).attr('href'));
    });
    // select change event to switchout content
    $tabs_select.on('change', function(){
      switchout(jQuery(this).find('option:selected').val());
    });
    // change content according to url hash
    if(hash.length>0) {
      switchout(hash);
    }
    function switchout(target){
      $tabs_select.find('option[value="'+target+'"]').attr('selected',true).siblings('option').attr('selected',false);
      $tabs.find('.tab-title a[href="'+target+'"]').closest('.tab-title').addClass('active').siblings('.active').removeClass('active');
      jQuery(target).addClass('active').siblings('.active').removeClass('active');
    }
  }

  if(jQuery('.events').length>0) {
    $('table.gf_directory td.text:first-child a').on('click',function(e){
      e.preventDefault();
        var link = $(this).attr('href');
        vbsEventModal(link);
    });
  }
});

function vbsEventModal(target){
  $('body').append('<div class="modal_overlay"></div>').addClass('modal-on');
  $('html').append('<div class="modal_container"><div class="modal_body"></div><div class="modal_footer"><span class="button">Close</span></div></div>');
  $('.modal_container .modal_body').load(target+" table", function() {
      $('.modal_footer .button, .modal_overlay').not('.modal_body').on('click',function(e){
        $('.modal_overlay, .modal_container').remove();
        $('body').removeClass('modal-on');
      });
  });
}
